package com.example.dass.ui

import android.annotation.SuppressLint
import android.net.Uri
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.dass.engine.graphics.DassRenderer
import com.example.dass.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("ClickableViewAccessibility")
@Composable
fun EngineCanvasScreen(
    viewModel: DassViewModel,
    onOpenExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val engineMode by viewModel.engineMode.collectAsStateWithLifecycle()
    val transformMode by viewModel.transformMode.collectAsStateWithLifecycle()
    val selectedObject by viewModel.selectedObject.collectAsStateWithLifecycle()
    val gameObjects by viewModel.gameObjects.collectAsStateWithLifecycle()
    val planetConfig by viewModel.planetConfig.collectAsStateWithLifecycle()
    val nearVehicle by viewModel.nearVehicle.collectAsStateWithLifecycle()
    val activeVehicle by viewModel.activeVehicle.collectAsStateWithLifecycle()
    val wireframeMode by viewModel.wireframeMode.collectAsStateWithLifecycle()

    var showAddDrawer by remember { mutableStateOf(false) }
    var showInspectorSheet by remember { mutableStateOf(false) }
    var showPlanetSheet by remember { mutableStateOf(false) }

    // Play Mode Joystick and Controls state
    var joypadVector by remember { mutableStateOf(Vec3(0f, 0f, 0f)) }
    var isSprintActive by remember { mutableStateOf(false) }
    var jumpTriggered by remember { mutableStateOf(false) }

    // Vehicle Driving Controls
    var throttleInput by remember { mutableFloatStateOf(0f) }
    var steerInput by remember { mutableFloatStateOf(0f) }
    var boostActive by remember { mutableStateOf(false) }

    // Handle back button
    BackHandler {
        if (engineMode == EngineMode.PLAY) {
            viewModel.setEngineMode(EngineMode.EDITOR)
        } else {
            viewModel.saveCurrentProject()
            viewModel.navigateTo(DassScreen.HOME)
        }
    }

    // SAF Importer for .obj / 3d models
    val objPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.importCustomMesh(it) }
    }

    // 3D Renderer instance reference
    val renderer = remember {
        DassRenderer(context) { selected ->
            viewModel.selectObject(selected?.id)
        }
    }

    // Keep renderer synced with Compose state
    LaunchedEffect(planetConfig) {
        renderer.planetConfig = planetConfig
        renderer.rebuildPlanetMeshes()
    }
    LaunchedEffect(gameObjects) {
        renderer.objects.clear()
        renderer.objects.addAll(gameObjects)
    }
    LaunchedEffect(selectedObject) {
        renderer.selectedObjectId = selectedObject?.id
    }
    LaunchedEffect(engineMode) {
        renderer.engineMode = engineMode
    }
    LaunchedEffect(transformMode) {
        renderer.transformMode = transformMode
    }
    LaunchedEffect(wireframeMode) {
        renderer.wireframeGlobal = wireframeMode
    }

    // Physics Engine Game Loop for Play Mode
    LaunchedEffect(engineMode, activeVehicle, joypadVector, isSprintActive, jumpTriggered, throttleInput, steerInput, boostActive) {
        if (engineMode == EngineMode.PLAY) {
            var lastTime = System.currentTimeMillis()
            while (true) {
                val now = System.currentTimeMillis()
                val delta = (now - lastTime) / 1000f
                lastTime = now

                if (activeVehicle != null) {
                    // Vehicle driving mode
                    val v = activeVehicle!!
                    val updatedV = viewModel.physics.updateVehicle(
                        vehicle = v,
                        throttleInput = throttleInput,
                        steerInput = steerInput,
                        boostActive = boostActive,
                        deltaTime = delta
                    )
                    viewModel.updateSelectedObject(updatedV)
                    // Camera smoothly follows vehicle
                    renderer.cameraTarget = updatedV.position
                } else {
                    // Character walking / running mode
                    val charObj = gameObjects.firstOrNull { it.type == ObjectType.CHARACTER }
                    if (charObj != null) {
                        val updatedChar = viewModel.physics.updateCharacter(
                            character = charObj,
                            moveInput = joypadVector,
                            isSprint = isSprintActive,
                            jumpTriggered = jumpTriggered,
                            cameraYaw = renderer.cameraAzimuth,
                            deltaTime = delta
                        )
                        jumpTriggered = false
                        viewModel.updateSelectedObject(updatedChar)

                        // Check proximity to driveable vehicles
                        viewModel.checkProximityToVehicles(updatedChar.position)

                        // Camera smoothly follows player
                        renderer.cameraTarget = updatedChar.position
                    }
                }
                delay(16) // ~60 FPS physics tick
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(VoidBlack)
    ) {
        // Native 3D GLSurfaceView Canvas
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                GLSurfaceView(ctx).apply {
                    setEGLContextClientVersion(2)
                    setRenderer(renderer)
                    renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

                    var prevX = 0f
                    var prevY = 0f
                    var touchMode = 0 // 0=none, 1=drag, 2=pinch

                    setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                prevX = event.x
                                prevY = event.y
                                touchMode = 1

                                if (engineMode == EngineMode.EDITOR) {
                                    renderer.handleTouchTap(event.x, event.y)
                                }
                            }
                            MotionEvent.ACTION_MOVE -> {
                                if (touchMode == 1 && event.pointerCount == 1) {
                                    val dx = event.x - prevX
                                    val dy = event.y - prevY

                                    if (engineMode == EngineMode.EDITOR && renderer.selectedObjectId != null && event.y > 200 && event.y < height - 300) {
                                        // Gizmo drag if near selected object
                                        renderer.handleGizmoDrag(dx, dy)
                                    } else {
                                        // Orbit camera
                                        renderer.cameraAzimuth += dx * 0.008f
                                        renderer.cameraElevation = (renderer.cameraElevation - dy * 0.008f)
                                            .coerceIn(-1.4f, 1.4f)
                                    }
                                } else if (event.pointerCount >= 2) {
                                    // Pinch zoom
                                    val p0x = event.getX(0); val p0y = event.getY(0)
                                    val p1x = event.getX(1); val p1y = event.getY(1)
                                    val dist = hypot((p0x - p1x).toDouble(), (p0y - p1y).toDouble()).toFloat()
                                    if (touchMode != 2) {
                                        touchMode = 2
                                    }
                                    renderer.cameraRadius = (renderer.cameraRadius - (dist * 0.005f))
                                        .coerceIn(14f, 90f)
                                }
                                prevX = event.x
                                prevY = event.y
                            }
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                                touchMode = 0
                            }
                        }
                        true
                    }
                }
            }
        )

        // Top Engine Control Bar
        TopEngineControlBar(
            projectName = currentProject?.name ?: "Dass Planet",
            engineMode = engineMode,
            wireframe = wireframeMode,
            onBack = {
                viewModel.saveCurrentProject()
                viewModel.navigateTo(DassScreen.HOME)
            },
            onToggleMode = {
                viewModel.setEngineMode(
                    if (engineMode == EngineMode.EDITOR) EngineMode.PLAY else EngineMode.EDITOR
                )
            },
            onToggleWireframe = { viewModel.toggleWireframe() },
            onSave = { viewModel.saveCurrentProject() },
            onExport = onOpenExport,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
        )

        // Transform Gizmo Toolbar (Editor Mode only)
        if (engineMode == EngineMode.EDITOR && selectedObject != null) {
            TransformGizmoBar(
                currentMode = transformMode,
                onModeChange = { viewModel.setTransformMode(it) },
                onDelete = { viewModel.deleteSelectedObject() },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 70.dp, end = 12.dp)
            )
        }

        // Bottom Shelf (Editor Mode: Add Mesh, Inspector, Planet Config)
        if (engineMode == EngineMode.EDITOR) {
            BottomEditorShelf(
                selectedObject = selectedObject,
                onOpenAdd = { showAddDrawer = true },
                onOpenInspector = { showInspectorSheet = true },
                onOpenPlanet = { showPlanetSheet = true },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 12.dp)
            )
        }

        // Play Mode HUD (Virtual Analog Joystick, Action Buttons, Vehicle Drive Prompts)
        if (engineMode == EngineMode.PLAY) {
            PlayModeHUD(
                activeVehicle = activeVehicle,
                nearVehicle = nearVehicle,
                isSprint = isSprintActive,
                onJoypadMove = { x, z -> joypadVector = Vec3(x, 0f, z) },
                onSprintToggle = { isSprintActive = !isSprintActive },
                onJump = { jumpTriggered = true },
                onEnterVehicle = { v -> viewModel.enterVehicle(v) },
                onExitVehicle = { viewModel.exitVehicle() },
                onThrottleChange = { throttleInput = it },
                onSteerChange = { steerInput = it },
                onBoostToggle = { boostActive = !boostActive },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            )
        }
    }

    // Add Object Bottom Sheet
    if (showAddDrawer) {
        ModalBottomSheet(
            onDismissRequest = { showAddDrawer = false },
            containerColor = SurfaceDark
        ) {
            AddAssetDrawerContent(
                onSelectAsset = { type, key, name ->
                    viewModel.addObjectToScene(type, key, name)
                    showAddDrawer = false
                },
                onImportCustom = {
                    objPicker.launch(arrayOf("*/*"))
                    showAddDrawer = false
                }
            )
        }
    }

    // Material & Transform Inspector Bottom Sheet
    if (showInspectorSheet && selectedObject != null) {
        ModalBottomSheet(
            onDismissRequest = { showInspectorSheet = false },
            containerColor = SurfaceDark
        ) {
            InspectorContent(
                gameObject = selectedObject!!,
                onUpdate = { updated -> viewModel.updateSelectedObject(updated) },
                onDelete = {
                    viewModel.deleteSelectedObject()
                    showInspectorSheet = false
                }
            )
        }
    }

    // Planet & Ocean Environment Bottom Sheet
    if (showPlanetSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlanetSheet = false },
            containerColor = SurfaceDark
        ) {
            PlanetEnvironmentContent(
                config = planetConfig,
                onUpdate = { updated -> viewModel.updatePlanetConfig(updated) }
            )
        }
    }
}

@Composable
fun TopEngineControlBar(
    projectName: String,
    engineMode: EngineMode,
    wireframe: Boolean,
    onBack: () -> Unit,
    onToggleMode: () -> Unit,
    onToggleWireframe: () -> Unit,
    onSave: () -> Unit,
    onExport: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        color = SurfaceDark.copy(alpha = 0.92f),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = projectName,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    ),
                    maxLines = 1
                )
                Text(
                    text = if (engineMode == EngineMode.EDITOR) "Sandbox Editor" else "Play Test Active",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (engineMode == EngineMode.EDITOR) CyanNeon else EmeraldSuccess,
                        fontSize = 10.sp
                    )
                )
            }

            // Mode Toggle (Editor ⇄ Play)
            Button(
                onClick = onToggleMode,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (engineMode == EngineMode.EDITOR) EmeraldSuccess else AmberEnergy
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("mode_toggle_button")
            ) {
                Icon(
                    imageVector = if (engineMode == EngineMode.EDITOR) Icons.Default.PlayArrow else Icons.Default.Edit,
                    contentDescription = null,
                    tint = VoidBlack,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (engineMode == EngineMode.EDITOR) "PLAY" else "EDIT",
                    color = VoidBlack,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Wireframe toggle
            IconButton(onClick = onToggleWireframe, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.GridOn,
                    contentDescription = "Wireframe",
                    tint = if (wireframe) CyanNeon else TextSecondary
                )
            }

            // Save Scene
            IconButton(onClick = onSave, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = "Save World",
                    tint = TextSecondary
                )
            }

            // Export APK button
            Button(
                onClick = onExport,
                colors = ButtonDefaults.buttonColors(containerColor = PurpleQuantum),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("export_apk_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Android,
                    contentDescription = null,
                    tint = TextPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("APK", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun TransformGizmoBar(
    currentMode: TransformMode,
    onModeChange: (TransformMode) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = SurfaceDark.copy(alpha = 0.92f),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
    ) {
        Column(
            modifier = Modifier.padding(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = { onModeChange(TransformMode.TRANSLATE) },
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentMode == TransformMode.TRANSLATE) SurfaceElevated else Color.Transparent)
            ) {
                Icon(
                    imageVector = Icons.Default.OpenWith,
                    contentDescription = "Translate Move",
                    tint = if (currentMode == TransformMode.TRANSLATE) CyanNeon else TextSecondary
                )
            }

            IconButton(
                onClick = { onModeChange(TransformMode.ROTATE) },
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentMode == TransformMode.ROTATE) SurfaceElevated else Color.Transparent)
            ) {
                Icon(
                    imageVector = Icons.Default.RotateRight,
                    contentDescription = "Rotate",
                    tint = if (currentMode == TransformMode.ROTATE) CyanNeon else TextSecondary
                )
            }

            IconButton(
                onClick = { onModeChange(TransformMode.SCALE) },
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (currentMode == TransformMode.SCALE) SurfaceElevated else Color.Transparent)
            ) {
                Icon(
                    imageVector = Icons.Default.AspectRatio,
                    contentDescription = "Scale",
                    tint = if (currentMode == TransformMode.SCALE) CyanNeon else TextSecondary
                )
            }

            Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 2.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete Selected",
                    tint = CrimsonAlert
                )
            }
        }
    }
}

@Composable
fun BottomEditorShelf(
    selectedObject: GameObject?,
    onOpenAdd: () -> Unit,
    onOpenInspector: () -> Unit,
    onOpenPlanet: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        color = SurfaceDark.copy(alpha = 0.94f),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onOpenAdd,
                colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = VoidBlack,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Add 3D Asset", color = VoidBlack, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onOpenInspector,
                enabled = selectedObject != null,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = if (selectedObject != null) CyanNeon else TextMuted
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (selectedObject != null) CyanNeon else SurfaceBorder
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Inspector")
            }

            IconButton(
                onClick = onOpenPlanet,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(SurfaceElevated)
            ) {
                Icon(
                    imageVector = Icons.Default.Water,
                    contentDescription = "Ocean & Planet",
                    tint = OceanBlue
                )
            }
        }
    }
}

@Composable
fun PlayModeHUD(
    activeVehicle: GameObject?,
    nearVehicle: GameObject?,
    isSprint: Boolean,
    onJoypadMove: (Float, Float) -> Unit,
    onSprintToggle: () -> Unit,
    onJump: () -> Unit,
    onEnterVehicle: (GameObject) -> Unit,
    onExitVehicle: () -> Unit,
    onThrottleChange: (Float) -> Unit,
    onSteerChange: (Float) -> Unit,
    onBoostToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .padding(16.dp)
    ) {
        if (activeVehicle != null) {
            // DRIVING VEHICLE HUD
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark.copy(alpha = 0.85f))
                    .border(1.dp, CyanNeon, RoundedCornerShape(12.dp))
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = activeVehicle.name.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = CyanNeon,
                        fontWeight = FontWeight.Bold
                    )
                )
                val speedKmh = ((activeVehicle.vehicleData?.currentSpeed ?: 0f) * 3.6f).toInt()
                Text(
                    text = "$speedKmh KM/H",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary
                    )
                )
            }

            // Steering Left / Right (Bottom Left)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = { onSteerChange(-1f) },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Steer Left",
                        tint = CyanNeon,
                        modifier = Modifier.size(28.dp)
                    )
                }

                IconButton(
                    onClick = { onSteerChange(1f) },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Steer Right",
                        tint = CyanNeon,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Throttle & Exit (Bottom Right)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Exit Vehicle
                Button(
                    onClick = onExitVehicle,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonAlert),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("EXIT", fontWeight = FontWeight.Bold)
                }

                // Reverse Pedal
                IconButton(
                    onClick = { onThrottleChange(-1f) },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Reverse",
                        tint = TextPrimary
                    )
                }

                // Forward Gas Pedal
                IconButton(
                    onClick = { onThrottleChange(1f) },
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(EmeraldSuccess)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Accelerate Gas",
                        tint = VoidBlack,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        } else {
            // CHARACTER ON-FOOT HUD
            // Virtual Touch Analog Joypad
            var joypadOffsetX by remember { mutableFloatStateOf(0f) }
            var joypadOffsetY by remember { mutableFloatStateOf(0f) }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .size(130.dp)
                    .clip(CircleShape)
                    .background(DarkNavy.copy(alpha = 0.7f))
                    .border(2.dp, CyanNeon.copy(alpha = 0.5f), CircleShape)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                joypadOffsetX = (joypadOffsetX + dragAmount.x).coerceIn(-45f, 45f)
                                joypadOffsetY = (joypadOffsetY + dragAmount.y).coerceIn(-45f, 45f)
                                onJoypadMove(joypadOffsetX / 45f, -joypadOffsetY / 45f)
                            },
                            onDragEnd = {
                                joypadOffsetX = 0f
                                joypadOffsetY = 0f
                                onJoypadMove(0f, 0f)
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Joypad Thumb Knob
                Box(
                    modifier = Modifier
                        .offset(joypadOffsetX.dp, joypadOffsetY.dp)
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(CyanNeon, OceanBlue)))
                        .border(1.dp, Color.White, CircleShape)
                )
            }

            // Floating "ENTER VEHICLE" Prompt when near a vehicle
            if (nearVehicle != null) {
                Button(
                    onClick = { onEnterVehicle(nearVehicle) },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberEnergy),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .border(1.dp, Color.White, RoundedCornerShape(12.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsCar,
                        contentDescription = null,
                        tint = VoidBlack
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DRIVE ${nearVehicle.name.uppercase()}",
                        color = VoidBlack,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            // Action Buttons (Jump, Sprint)
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sprint Button
                IconButton(
                    onClick = onSprintToggle,
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(if (isSprint) AmberEnergy else SurfaceElevated)
                        .border(1.dp, SurfaceBorder, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Sprint",
                        tint = if (isSprint) VoidBlack else TextPrimary
                    )
                }

                // Jump Button
                IconButton(
                    onClick = onJump,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(CyanNeon)
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Jump",
                        tint = VoidBlack,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AddAssetDrawerContent(
    onSelectAsset: (ObjectType, String, String) -> Unit,
    onImportCustom: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "ADD 3D ASSETS TO PLANET",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )

        val assets = listOf(
            Triple(ObjectType.CHARACTER, "character", "Astronaut Hero"),
            Triple(ObjectType.VEHICLE, "rover", "All-Terrain Buggy"),
            Triple(ObjectType.VEHICLE, "spaceship", "Orbital Starship"),
            Triple(ObjectType.VEHICLE, "speedboat", "Speedboat Watercraft"),
            Triple(ObjectType.BUILDING, "dome", "Sci-Fi Colony Dome"),
            Triple(ObjectType.NATURE, "tree", "Alien Palm Tree"),
            Triple(ObjectType.NATURE, "crystal", "Neon Crystal Spire"),
            Triple(ObjectType.ANIMAL, "quadruped", "Cyber Wolf Hound")
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(assets) { (type, key, name) ->
                Card(
                    modifier = Modifier
                        .width(130.dp)
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectAsset(type, key, name) }
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (type) {
                                    ObjectType.CHARACTER -> Icons.Default.Person
                                    ObjectType.VEHICLE -> Icons.Default.DirectionsCar
                                    ObjectType.BUILDING -> Icons.Default.Apartment
                                    ObjectType.NATURE -> Icons.Default.Park
                                    ObjectType.ANIMAL -> Icons.Default.Pets
                                    else -> Icons.Default.Category
                                },
                                contentDescription = null,
                                tint = CyanNeon
                            )
                        }

                        Column {
                            Text(
                                text = name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = type.displayName,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // Custom File Import (.OBJ / .GLTF)
        Button(
            onClick = onImportCustom,
            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(imageVector = Icons.Default.UploadFile, contentDescription = null, tint = CyanNeon)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Import 3D Model (.obj / .gltf) from Device", color = CyanNeon)
        }
    }
}

@Composable
fun InspectorContent(
    gameObject: GameObject,
    onUpdate: (GameObject) -> Unit,
    onDelete: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = gameObject.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "Type: ${gameObject.type.displayName}",
                    style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon)
                )
            }

            IconButton(onClick = onDelete) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonAlert)
            }
        }

        // Material Palette Selector
        Text(
            text = "MATERIAL ALBEDO TINT",
            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontWeight = FontWeight.Bold)
        )
        val colorPalette = listOf(
            "#00E5FF", "#FF9100", "#7C4DFF", "#00E676", "#FF5252", "#F72585", "#FFFFFF", "#1E293B"
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            colorPalette.forEach { hex ->
                val isSelected = gameObject.material.albedoHex.equals(hex, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.parseColor(hex)))
                        .border(
                            2.dp,
                            if (isSelected) Color.White else Color.Transparent,
                            CircleShape
                        )
                        .clickable {
                            onUpdate(gameObject.copy(material = gameObject.material.copy(albedoHex = hex)))
                        }
                )
            }
        }

        // Metallic Slider
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Metallic", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(80.dp))
            Slider(
                value = gameObject.material.metallic,
                onValueChange = { onUpdate(gameObject.copy(material = gameObject.material.copy(metallic = it))) },
                colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon),
                modifier = Modifier.weight(1f)
            )
        }

        // Roughness Slider
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Roughness", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(80.dp))
            Slider(
                value = gameObject.material.roughness,
                onValueChange = { onUpdate(gameObject.copy(material = gameObject.material.copy(roughness = it))) },
                colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon),
                modifier = Modifier.weight(1f)
            )
        }

        // Animation Rig Selector (if animated)
        Text(
            text = "ANIMATION RIG CLIP",
            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontWeight = FontWeight.Bold)
        )
        val clips = listOf("Idle", "Walk", "Run", "Jump")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            clips.forEach { clip ->
                val isSel = gameObject.animationState.clipName == clip
                FilterChip(
                    selected = isSel,
                    onClick = {
                        onUpdate(gameObject.copy(animationState = gameObject.animationState.copy(clipName = clip)))
                    },
                    label = { Text(clip) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanNeon,
                        selectedLabelColor = VoidBlack
                    )
                )
            }
        }
    }
}

@Composable
fun PlanetEnvironmentContent(
    config: PlanetConfig,
    onUpdate: (PlanetConfig) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "PLANET & OCEAN DYNAMICS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        )

        // Wave Speed
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Wave Speed", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(90.dp))
            Slider(
                value = config.waveSpeed,
                onValueChange = { onUpdate(config.copy(waveSpeed = it)) },
                valueRange = 0f..4f,
                colors = SliderDefaults.colors(thumbColor = OceanBlue, activeTrackColor = OceanBlue),
                modifier = Modifier.weight(1f)
            )
        }

        // Wave Amplitude
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Amplitude", style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(90.dp))
            Slider(
                value = config.waveAmplitude,
                onValueChange = { onUpdate(config.copy(waveAmplitude = it)) },
                valueRange = 0f..0.5f,
                colors = SliderDefaults.colors(thumbColor = OceanBlue, activeTrackColor = OceanBlue),
                modifier = Modifier.weight(1f)
            )
        }

        // Ocean Color Presets
        Text(
            text = "OCEAN WATER COLOR",
            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontWeight = FontWeight.Bold)
        )
        val oceanPresets = listOf("#0077B6", "#03045E", "#7209B7", "#D00000", "#00B4D8")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            oceanPresets.forEach { hex ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(android.graphics.Color.parseColor(hex)))
                        .border(
                            2.dp,
                            if (config.oceanColorHex == hex) Color.White else Color.Transparent,
                            CircleShape
                        )
                        .clickable { onUpdate(config.copy(oceanColorHex = hex)) }
                )
            }
        }
    }
}
