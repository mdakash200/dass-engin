package com.example.dass.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class PlanetPreset(val label: String, val description: String) {
    OCEAN_WORLD("Ocean World", "Luminous water planet with scattered tropical archipelagos"),
    CYBER_DUNES("Cyber Dunes", "Neon desert planet with low-poly crystalline ridges"),
    VOLCANIC_CRATER("Volcanic Core", "Molten planetary mantle with cooling basalt shields"),
    ICE_CRYSTAL("Glacial Spire", "Sub-zero frozen planet with reflective ice glaciers"),
    LOW_POLY_MOON("Lunar Outpost", "Barren cratered asteroid with low gravity physics")
}

enum class ObjectType(val displayName: String) {
    CHARACTER("Player Character"),
    VEHICLE("Driveable Vehicle"),
    BUILDING("Sci-Fi Structure"),
    NATURE("Flora & Terrain"),
    PROP("Physics Prop"),
    ANIMAL("Quadruped Creature"),
    CUSTOM_MESH("Imported Mesh")
}

enum class VehicleType(val label: String, val speedFactor: Float) {
    WHEELED("Wheeled Rover", 1.2f),
    FLYING("Orbital Starship", 2.5f),
    FLOATING("Water Speedboat", 1.5f)
}

enum class TransformMode {
    TRANSLATE, ROTATE, SCALE
}

enum class EngineMode {
    EDITOR, PLAY
}

enum class RenderQuality(val label: String, val maxLights: Int, val shadowRes: Int) {
    LOW("Performance (Low)", 2, 512),
    MEDIUM("Balanced (Med)", 4, 1024),
    ULTRA("Ultra Visuals", 8, 2048)
}

enum class TargetFps(val fps: Int) {
    FPS_30(30),
    FPS_60(60),
    FPS_120(120)
}

data class Vec3(
    val x: Float = 0f,
    val y: Float = 0f,
    val z: Float = 0f
) {
    fun length(): Float = kotlin.math.sqrt(x * x + y * y + z * z)
    fun normalized(): Vec3 {
        val l = length()
        return if (l > 0.00001f) Vec3(x / l, y / l, z / l) else Vec3(0f, 1f, 0f)
    }
    operator fun plus(other: Vec3): Vec3 = Vec3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vec3): Vec3 = Vec3(x - other.x, y - other.y, z - other.z)
    operator fun times(scale: Float): Vec3 = Vec3(x * scale, y * scale, z * scale)
    fun distanceTo(other: Vec3): Float = (this - other).length()
}

data class MaterialData(
    val albedoHex: String = "#00E5FF",
    val metallic: Float = 0.2f,
    val roughness: Float = 0.4f,
    val emissionHex: String = "#000000",
    val emissionIntensity: Float = 0f,
    val textureKey: String = "grid", // grid, plating, hex, rock, water, bark
    val wireframe: Boolean = false
)

data class AnimationState(
    val clipName: String = "Idle", // Idle, Walk, Run, Jump, Drive, Fly
    val speed: Float = 1.0f,
    val isPlaying: Boolean = true
)

data class VehicleData(
    val type: VehicleType = VehicleType.WHEELED,
    val maxSpeed: Float = 18f,
    val acceleration: Float = 8f,
    val steeringSensitivity: Float = 1.5f,
    val currentSpeed: Float = 0f,
    val isPlayerOccupied: Boolean = false
)

data class GameObject(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ObjectType,
    val position: Vec3,
    val rotation: Vec3 = Vec3(0f, 0f, 0f), // Euler angles in degrees
    val scale: Vec3 = Vec3(1f, 1f, 1f),
    val material: MaterialData = MaterialData(),
    val animationState: AnimationState = AnimationState(),
    val vehicleData: VehicleData? = null,
    val meshKey: String = "cube", // built-in primitive or custom mesh key
    val customModelPath: String? = null
)

data class PlanetConfig(
    val radius: Float = 12f,
    val oceanRadius: Float = 12.2f,
    val oceanColorHex: String = "#0077B6",
    val terrainColorHex: String = "#2D6A4F",
    val atmosphereColorHex: String = "#00E5FF",
    val waveSpeed: Float = 1.2f,
    val waveAmplitude: Float = 0.15f,
    val atmosphereGlow: Float = 1.5f,
    val seed: Long = 42L,
    val rotationSpeed: Float = 0.05f
)

data class SettingsConfig(
    val targetFps: TargetFps = TargetFps.FPS_60,
    val renderQuality: RenderQuality = RenderQuality.MEDIUM,
    val shadowEnabled: Boolean = true,
    val bloomEnabled: Boolean = true,
    val wireframeMode: Boolean = false,
    val masterVolume: Float = 0.8f,
    val sfxVolume: Float = 0.9f,
    val bgmVolume: Float = 0.6f,
    val gravity: Float = -9.8f,
    val sphericalGravity: Boolean = true,
    val collisionPrecisionHigh: Boolean = true,
    val physicsTickRate: Int = 60, // 30, 60, 120
    val defaultPackagePrefix: String = "com.dass.game",
    val targetSdk: Int = 36,
    val exportPermissions: List<String> = listOf("INTERNET", "VIBRATE")
)

data class ExportConfig(
    val appName: String = "My Dass World",
    val packageName: String = "com.dass.game.sandbox",
    val versionCode: Int = 1,
    val versionName: String = "1.0.0",
    val minSdk: Int = 24,
    val targetSdk: Int = 36,
    val permissions: List<String> = listOf("INTERNET", "VIBRATE")
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val iconUri: String? = null,
    val presetName: String = PlanetPreset.OCEAN_WORLD.name,
    val targetFps: Int = 60,
    val renderQuality: String = RenderQuality.MEDIUM.name,
    val exportPackage: String = "com.dass.game.world",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val sceneJson: String
)
