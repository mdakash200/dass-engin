package com.example.dass.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.dass.data.AppDatabase
import com.example.dass.data.ProjectRepository
import com.example.dass.data.SceneBundle
import com.example.dass.data.SceneSerializer
import com.example.dass.engine.export.ApkExportPipeline
import com.example.dass.engine.export.ApkExportResult
import com.example.dass.engine.export.BuildStep
import com.example.dass.engine.importer.Model3DImporter
import com.example.dass.engine.physics.SphericalPhysics
import com.example.dass.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.max

enum class DassScreen {
    HOME, ENGINE_CANVAS, SETTINGS
}

class DassViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository
    val physics = SphericalPhysics()

    // Navigation
    private val _currentScreen = MutableStateFlow(DassScreen.HOME)
    val currentScreen: StateFlow<DassScreen> = _currentScreen.asStateFlow()

    // Database Projects
    val allProjects: StateFlow<List<ProjectEntity>>

    // Current Project & Scene
    private val _currentProject = MutableStateFlow<ProjectEntity?>(null)
    val currentProject: StateFlow<ProjectEntity?> = _currentProject.asStateFlow()

    private val _planetConfig = MutableStateFlow(PlanetConfig())
    val planetConfig: StateFlow<PlanetConfig> = _planetConfig.asStateFlow()

    private val _gameObjects = MutableStateFlow<List<GameObject>>(emptyList())
    val gameObjects: StateFlow<List<GameObject>> = _gameObjects.asStateFlow()

    private val _settingsConfig = MutableStateFlow(SettingsConfig())
    val settingsConfig: StateFlow<SettingsConfig> = _settingsConfig.asStateFlow()

    // Engine Canvas State
    private val _engineMode = MutableStateFlow(EngineMode.EDITOR)
    val engineMode: StateFlow<EngineMode> = _engineMode.asStateFlow()

    private val _transformMode = MutableStateFlow(TransformMode.TRANSLATE)
    val transformMode: StateFlow<TransformMode> = _transformMode.asStateFlow()

    private val _selectedObjectId = MutableStateFlow<String?>(null)
    val selectedObjectId: StateFlow<String?> = _selectedObjectId.asStateFlow()

    val selectedObject: StateFlow<GameObject?> = combine(_gameObjects, _selectedObjectId) { list, id ->
        list.firstOrNull { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Vehicle Interaction
    private val _nearVehicle = MutableStateFlow<GameObject?>(null)
    val nearVehicle: StateFlow<GameObject?> = _nearVehicle.asStateFlow()

    private val _activeVehicle = MutableStateFlow<GameObject?>(null)
    val activeVehicle: StateFlow<GameObject?> = _activeVehicle.asStateFlow()

    // Wireframe Mode
    private val _wireframeMode = MutableStateFlow(false)
    val wireframeMode: StateFlow<Boolean> = _wireframeMode.asStateFlow()

    // APK Export Pipeline
    private val _exportStep = MutableStateFlow<BuildStep?>(null)
    val exportStep: StateFlow<BuildStep?> = _exportStep.asStateFlow()

    private val _exportResult = MutableStateFlow<ApkExportResult?>(null)
    val exportResult: StateFlow<ApkExportResult?> = _exportResult.asStateFlow()

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ProjectRepository(db.projectDao())
        allProjects = repository.allProjects.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        viewModelScope.launch(Dispatchers.IO) {
            repository.initializeDefaultTemplatesIfNeeded()
        }
    }

    fun navigateTo(screen: DassScreen) {
        _currentScreen.value = screen
    }

    fun setEngineMode(mode: EngineMode) {
        _engineMode.value = mode
        if (mode == EngineMode.EDITOR) {
            // Exit vehicle if in vehicle
            if (_activeVehicle.value != null) {
                exitVehicle()
            }
        }
    }

    fun setTransformMode(mode: TransformMode) {
        _transformMode.value = mode
    }

    fun selectObject(id: String?) {
        _selectedObjectId.value = id
    }

    fun toggleWireframe() {
        _wireframeMode.value = !_wireframeMode.value
    }

    fun createNewPlanet(name: String, preset: PlanetPreset, iconUri: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val planet = when (preset) {
                PlanetPreset.OCEAN_WORLD -> PlanetConfig(
                    radius = 12f,
                    oceanRadius = 12.25f,
                    oceanColorHex = "#0077B6",
                    terrainColorHex = "#2A9D8F",
                    atmosphereColorHex = "#00E5FF",
                    waveSpeed = 1.3f,
                    waveAmplitude = 0.2f
                )
                PlanetPreset.CYBER_DUNES -> PlanetConfig(
                    radius = 12f,
                    oceanRadius = 11.4f,
                    oceanColorHex = "#7209B7",
                    terrainColorHex = "#F72585",
                    atmosphereColorHex = "#4CC9F0",
                    waveSpeed = 0.8f,
                    waveAmplitude = 0.05f
                )
                PlanetPreset.VOLCANIC_CRATER -> PlanetConfig(
                    radius = 12f,
                    oceanRadius = 12.1f,
                    oceanColorHex = "#D00000",
                    terrainColorHex = "#370617",
                    atmosphereColorHex = "#FFBA08",
                    waveSpeed = 0.6f,
                    waveAmplitude = 0.12f
                )
                PlanetPreset.ICE_CRYSTAL -> PlanetConfig(
                    radius = 12f,
                    oceanRadius = 12.15f,
                    oceanColorHex = "#90E0EF",
                    terrainColorHex = "#CAF0F8",
                    atmosphereColorHex = "#00B4D8",
                    waveSpeed = 0.4f,
                    waveAmplitude = 0.08f
                )
                PlanetPreset.LOW_POLY_MOON -> PlanetConfig(
                    radius = 12f,
                    oceanRadius = 0f,
                    oceanColorHex = "#1B263B",
                    terrainColorHex = "#778DA9",
                    atmosphereColorHex = "#415A77",
                    waveSpeed = 0f,
                    waveAmplitude = 0f
                )
            }

            val defaultChar = GameObject(
                name = "Explorer",
                type = ObjectType.CHARACTER,
                position = Vec3(0f, 12.4f, 0f),
                material = MaterialData(albedoHex = "#00E5FF", metallic = 0.3f, roughness = 0.3f),
                meshKey = "character"
            )

            val starterRover = GameObject(
                name = "Planetary Buggy",
                type = ObjectType.VEHICLE,
                position = Vec3(2.5f, 12.35f, 2.0f),
                material = MaterialData(albedoHex = "#FF9100", metallic = 0.7f, roughness = 0.3f),
                meshKey = "rover",
                vehicleData = VehicleData(VehicleType.WHEELED, maxSpeed = 22f, acceleration = 10f)
            )

            val initialObjects = listOf(defaultChar, starterRover)
            val bundle = SceneBundle(planet, initialObjects, _settingsConfig.value)
            val json = SceneSerializer.serializeScene(bundle)

            val entity = ProjectEntity(
                name = name.ifBlank { "Uncharted Planet" },
                iconUri = iconUri,
                presetName = preset.name,
                targetFps = 60,
                renderQuality = RenderQuality.MEDIUM.name,
                exportPackage = "com.dass.game.${name.lowercase().replace("[^a-z0-9]".toRegex(), "_")}",
                sceneJson = json
            )

            val id = repository.insertProject(entity)
            val loaded = repository.getProjectById(id) ?: entity.copy(id = id)

            loadProject(loaded)
        }
    }

    fun loadProject(project: ProjectEntity) {
        _currentProject.value = project
        val bundle = try {
            SceneSerializer.deserializeScene(project.sceneJson)
        } catch (_: Exception) {
            SceneBundle(PlanetConfig(), emptyList(), SettingsConfig())
        }

        _planetConfig.value = bundle.planetConfig
        _gameObjects.value = bundle.objects
        _settingsConfig.value = bundle.settingsConfig
        _selectedObjectId.value = bundle.objects.firstOrNull()?.id
        _engineMode.value = EngineMode.EDITOR

        physics.planetRadius = bundle.planetConfig.radius
        physics.oceanRadius = bundle.planetConfig.oceanRadius
        physics.gravity = bundle.settingsConfig.gravity

        _currentScreen.value = DassScreen.ENGINE_CANVAS
    }

    fun saveCurrentProject() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val bundle = SceneBundle(_planetConfig.value, _gameObjects.value, _settingsConfig.value)
            val json = SceneSerializer.serializeScene(bundle)
            val updated = proj.copy(
                updatedAt = System.currentTimeMillis(),
                sceneJson = json
            )
            repository.updateProject(updated)
            _currentProject.value = updated
        }
    }

    fun deleteProject(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProjectById(id)
            if (_currentProject.value?.id == id) {
                _currentProject.value = null
                _currentScreen.value = DassScreen.HOME
            }
        }
    }

    fun duplicateProject(project: ProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val copy = project.copy(
                id = 0,
                name = "${project.name} (Copy)",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            repository.insertProject(copy)
        }
    }

    fun addObjectToScene(type: ObjectType, meshKey: String, name: String) {
        val pRadius = _planetConfig.value.radius
        val surfaceOffset = when (meshKey) {
            "character" -> 0.4f
            "rover", "spaceship", "speedboat" -> 0.35f
            "tree", "crystal" -> 0.1f
            else -> 0.2f
        }
        val yPos = max(pRadius, _planetConfig.value.oceanRadius) + surfaceOffset

        val vehicleData = if (type == ObjectType.VEHICLE) {
            when (meshKey) {
                "rover" -> VehicleData(VehicleType.WHEELED, maxSpeed = 22f, acceleration = 10f)
                "spaceship" -> VehicleData(VehicleType.FLYING, maxSpeed = 35f, acceleration = 18f)
                "speedboat" -> VehicleData(VehicleType.FLOATING, maxSpeed = 20f, acceleration = 12f)
                else -> VehicleData(VehicleType.WHEELED)
            }
        } else null

        val newObj = GameObject(
            id = UUID.randomUUID().toString(),
            name = name,
            type = type,
            position = Vec3(0f, yPos, 0f),
            scale = when (meshKey) {
                "character" -> Vec3(1f, 1.8f, 1f)
                "rover" -> Vec3(1.6f, 1f, 2.2f)
                "spaceship" -> Vec3(2f, 0.8f, 2.8f)
                "speedboat" -> Vec3(1.4f, 0.9f, 2.5f)
                "dome" -> Vec3(3.5f, 2.5f, 3.5f)
                "tree" -> Vec3(1.2f, 2.2f, 1.2f)
                "crystal" -> Vec3(1.2f, 3.0f, 1.2f)
                "quadruped" -> Vec3(0.9f, 0.9f, 1.4f)
                else -> Vec3(1f, 1f, 1f)
            },
            material = MaterialData(
                albedoHex = when (meshKey) {
                    "character" -> "#00E5FF"
                    "rover" -> "#FF9100"
                    "spaceship" -> "#7C4DFF"
                    "speedboat" -> "#00F5D4"
                    "dome" -> "#4CC9F0"
                    "tree" -> "#06D6A0"
                    "crystal" -> "#F72585"
                    "quadruped" -> "#E76F51"
                    else -> "#00E5FF"
                }
            ),
            vehicleData = vehicleData,
            meshKey = meshKey
        )

        _gameObjects.value = _gameObjects.value + newObj
        _selectedObjectId.value = newObj.id
    }

    fun updateSelectedObject(updated: GameObject) {
        _gameObjects.value = _gameObjects.value.map {
            if (it.id == updated.id) updated else it
        }
    }

    fun deleteSelectedObject() {
        val selId = _selectedObjectId.value ?: return
        _gameObjects.value = _gameObjects.value.filter { it.id != selId }
        _selectedObjectId.value = _gameObjects.value.firstOrNull()?.id
    }

    fun updatePlanetConfig(config: PlanetConfig) {
        _planetConfig.value = config
        physics.planetRadius = config.radius
        physics.oceanRadius = config.oceanRadius
    }

    fun updateSettings(settings: SettingsConfig) {
        _settingsConfig.value = settings
        physics.gravity = settings.gravity
        physics.isSpherical = settings.sphericalGravity
    }

    fun importCustomMesh(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = Model3DImporter.loadFromUri(getApplication(), uri)
            if (result.isSuccess) {
                addObjectToScene(ObjectType.CUSTOM_MESH, "custom", "Imported 3D Mesh")
            }
        }
    }

    fun checkProximityToVehicles(playerPos: Vec3) {
        val vehicles = _gameObjects.value.filter { it.type == ObjectType.VEHICLE }
        var closestVehicle: GameObject? = null
        var closestDist = Float.MAX_VALUE

        for (v in vehicles) {
            val dist = playerPos.distanceTo(v.position)
            if (dist < 3.5f && dist < closestDist) {
                closestDist = dist
                closestVehicle = v
            }
        }
        _nearVehicle.value = closestVehicle
    }

    fun enterVehicle(vehicle: GameObject) {
        _activeVehicle.value = vehicle
        physics.activeVehicle = vehicle
        physics.vehicleSpeed = 0f
    }

    fun exitVehicle() {
        val v = _activeVehicle.value ?: return
        _activeVehicle.value = null
        physics.activeVehicle = null

        // Position player next to vehicle
        val charIdx = _gameObjects.value.indexOfFirst { it.type == ObjectType.CHARACTER }
        if (charIdx >= 0) {
            val char = _gameObjects.value[charIdx]
            val exitPos = v.position + Vec3(1.5f, 0f, 1.5f)
            _gameObjects.value = _gameObjects.value.toMutableList().apply {
                this[charIdx] = char.copy(position = exitPos)
            }
        }
    }

    fun startApkExport(config: ExportConfig) {
        _isExporting.value = true
        _exportStep.value = null
        _exportResult.value = null

        viewModelScope.launch(Dispatchers.IO) {
            val bundle = SceneBundle(_planetConfig.value, _gameObjects.value, _settingsConfig.value)
            ApkExportPipeline.buildAndPackageApk(getApplication(), config, bundle).collect { step ->
                _exportStep.value = step
            }
            val result = ApkExportPipeline.createApkFile(getApplication(), config, bundle)
            _exportResult.value = result
            _isExporting.value = false
        }
    }

    fun dismissExportDialog() {
        _exportStep.value = null
        _exportResult.value = null
        _isExporting.value = false
    }
}
