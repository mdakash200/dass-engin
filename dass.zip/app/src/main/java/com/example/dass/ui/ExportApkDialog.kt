package com.example.dass.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.dass.engine.export.ApkExportPipeline
import com.example.dass.model.ExportConfig
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportApkDialog(
    viewModel: DassViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val currentProject by viewModel.currentProject.collectAsStateWithLifecycle()
    val isExporting by viewModel.isExporting.collectAsStateWithLifecycle()
    val exportStep by viewModel.exportStep.collectAsStateWithLifecycle()
    val exportResult by viewModel.exportResult.collectAsStateWithLifecycle()

    var appName by remember {
        mutableStateOf(currentProject?.name ?: "Dass Planet Game")
    }
    var packageName by remember {
        mutableStateOf(currentProject?.exportPackage ?: "com.dass.game.planet")
    }
    var versionName by remember { mutableStateOf("1.0.0") }
    var selectedPermissions by remember {
        mutableStateOf(listOf("INTERNET", "VIBRATE"))
    }

    AlertDialog(
        onDismissRequest = {
            if (!isExporting) {
                viewModel.dismissExportDialog()
                onDismiss()
            }
        },
        containerColor = SurfaceDark,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PurpleQuantum),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Export Standalone APK",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "Mobile Runtime Compiler v1.0.4",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = CyanNeon,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (exportResult != null) {
                    // Export Result view
                    val res = exportResult!!
                    if (res.success) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(SurfaceCard)
                                .border(1.dp, EmeraldSuccess, RoundedCornerShape(12.dp))
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldSuccess),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = VoidBlack,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "APK COMPILED SUCCESSFULLY",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = EmeraldSuccess,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = res.apkFile?.name ?: "app-release.apk",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Size: ${res.fileSizeFormatted} · Package: ${res.packageName}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextMuted
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "SHA-256: ${res.sha256Checksum.take(24)}...",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = FontFamily.Monospace,
                                    color = CyanNeon,
                                    fontSize = 10.sp
                                )
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        res.apkFile?.let { file ->
                                            try {
                                                val intent = ApkExportPipeline.getInstallIntent(context, file)
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(imageVector = Icons.Default.InstallMobile, contentDescription = null, tint = VoidBlack)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Install APK", color = VoidBlack, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        res.apkFile?.let { file ->
                                            try {
                                                val intent = ApkExportPipeline.getShareIntent(context, file)
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CyanNeon)
                                ) {
                                    Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = CyanNeon)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share", color = CyanNeon)
                                }
                            }
                        }
                    } else {
                        // Error
                        Text(
                            text = "Compilation Failed: ${res.errorMessage}",
                            color = CrimsonAlert,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                } else if (isExporting || exportStep != null) {
                    // Compilation progress view
                    val step = exportStep ?: com.example.dass.engine.export.BuildStep(1, 6, "Initializing...", "", 0.1f)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceCard)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "STEP ${step.step} OF ${step.totalSteps}: ${step.title.uppercase()}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CyanNeon,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        LinearProgressIndicator(
                            progress = { step.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = CyanNeon,
                            trackColor = SurfaceElevated
                        )
                        Text(
                            text = step.detail,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                } else {
                    // Config form
                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text("Game App Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_app_name_input")
                    )

                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it },
                        label = { Text("Android Package Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = SurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_package_name_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = versionName,
                            onValueChange = { versionName = it },
                            label = { Text("Version") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = SurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = "SDK 36",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Target SDK") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanNeon,
                                unfocusedBorderColor = SurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Text(
                        text = "PERMISSIONS TO BUNDLE IN APK",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextMuted,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("INTERNET", "VIBRATE", "CAMERA").forEach { perm ->
                            val isSel = selectedPermissions.contains(perm)
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    selectedPermissions = if (isSel) {
                                        selectedPermissions - perm
                                    } else {
                                        selectedPermissions + perm
                                    }
                                },
                                label = { Text(perm, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurpleQuantum,
                                    selectedLabelColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (exportResult == null && !isExporting) {
                Button(
                    onClick = {
                        val config = ExportConfig(
                            appName = appName,
                            packageName = packageName,
                            versionName = versionName,
                            permissions = selectedPermissions
                        )
                        viewModel.startApkExport(config)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                    modifier = Modifier.testTag("start_apk_build_button")
                ) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, tint = VoidBlack)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Build Standalone APK", color = VoidBlack, fontWeight = FontWeight.Bold)
                }
            } else if (exportResult != null) {
                Button(
                    onClick = {
                        viewModel.dismissExportDialog()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated)
                ) {
                    Text("Done", color = TextPrimary)
                }
            }
        },
        dismissButton = {
            if (!isExporting) {
                TextButton(
                    onClick = {
                        viewModel.dismissExportDialog()
                        onDismiss()
                    }
                ) {
                    Text("Close", color = TextSecondary)
                }
            }
        }
    )
}
