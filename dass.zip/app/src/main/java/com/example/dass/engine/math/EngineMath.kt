package com.example.dass.engine.math

import android.opengl.Matrix
import com.example.dass.model.Vec3
import kotlin.math.*

class Mat4 {
    val data = FloatArray(16)

    init {
        Matrix.setIdentityM(data, 0)
    }

    fun setIdentity(): Mat4 {
        Matrix.setIdentityM(data, 0)
        return this
    }

    fun multiply(other: Mat4): Mat4 {
        val result = FloatArray(16)
        Matrix.multiplyMM(result, 0, this.data, 0, other.data, 0)
        System.arraycopy(result, 0, this.data, 0, 16)
        return this
    }

    fun translate(x: Float, y: Float, z: Float): Mat4 {
        Matrix.translateM(data, 0, x, y, z)
        return this
    }

    fun rotate(angleDeg: Float, x: Float, y: Float, z: Float): Mat4 {
        Matrix.rotateM(data, 0, angleDeg, x, y, z)
        return this
    }

    fun scale(x: Float, y: Float, z: Float): Mat4 {
        Matrix.scaleM(data, 0, x, y, z)
        return this
    }

    companion object {
        fun identity(): Mat4 = Mat4()

        fun perspective(fovyDeg: Float, aspect: Float, near: Float, far: Float): Mat4 {
            val m = Mat4()
            Matrix.perspectiveM(m.data, 0, fovyDeg, aspect, near, far)
            return m
        }

        fun lookAt(eye: Vec3, target: Vec3, up: Vec3): Mat4 {
            val m = Mat4()
            Matrix.setLookAtM(
                m.data, 0,
                eye.x, eye.y, eye.z,
                target.x, target.y, target.z,
                up.x, up.y, up.z
            )
            return m
        }
    }
}

data class Ray(val origin: Vec3, val direction: Vec3) {
    fun intersectSphere(center: Vec3, radius: Float): Float? {
        val oc = origin - center
        val a = direction.x * direction.x + direction.y * direction.y + direction.z * direction.z
        val b = 2f * (oc.x * direction.x + oc.y * direction.y + oc.z * direction.z)
        val c = (oc.x * oc.x + oc.y * oc.y + oc.z * oc.z) - radius * radius
        val discriminant = b * b - 4 * a * c
        if (discriminant < 0f) return null
        val t0 = (-b - sqrt(discriminant)) / (2f * a)
        val t1 = (-b + sqrt(discriminant)) / (2f * a)
        return when {
            t0 > 0.01f -> t0
            t1 > 0.01f -> t1
            else -> null
        }
    }

    fun intersectPlane(pointOnPlane: Vec3, normal: Vec3): Float? {
        val denom = normal.x * direction.x + normal.y * direction.y + normal.z * direction.z
        if (abs(denom) > 1e-6) {
            val p0l0 = pointOnPlane - origin
            val t = (p0l0.x * normal.x + p0l0.y * normal.y + p0l0.z * normal.z) / denom
            if (t >= 0f) return t
        }
        return null
    }

    fun getPoint(t: Float): Vec3 = origin + direction * t
}

object RaycastHelper {
    fun screenPointToRay(
        touchX: Float,
        touchY: Float,
        screenWidth: Int,
        screenHeight: Int,
        viewMatrix: Mat4,
        projMatrix: Mat4
    ): Ray {
        // Normalized Device Coordinates (-1 to 1)
        val x = (2.0f * touchX) / screenWidth - 1.0f
        val y = 1.0f - (2.0f * touchY) / screenHeight

        val invViewProj = FloatArray(16)
        val viewProj = FloatArray(16)
        Matrix.multiplyMM(viewProj, 0, projMatrix.data, 0, viewMatrix.data, 0)
        Matrix.invertM(invViewProj, 0, viewProj, 0)

        val nearPoint = FloatArray(4)
        val farPoint = FloatArray(4)

        Matrix.multiplyMV(nearPoint, 0, invViewProj, 0, floatArrayOf(x, y, -1f, 1f), 0)
        Matrix.multiplyMV(farPoint, 0, invViewProj, 0, floatArrayOf(x, y, 1f, 1f), 0)

        val nearW = nearPoint[3]
        val farW = farPoint[3]

        val nearVec = Vec3(nearPoint[0] / nearW, nearPoint[1] / nearW, nearPoint[2] / nearW)
        val farVec = Vec3(farPoint[0] / farW, farPoint[1] / farW, farPoint[2] / farW)

        val dir = (farVec - nearVec).normalized()
        return Ray(nearVec, dir)
    }
}
