package com.example.dass.engine.graphics

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.example.dass.engine.math.Mat4
import com.example.dass.engine.math.Ray
import com.example.dass.engine.math.RaycastHelper
import com.example.dass.model.*
import java.util.concurrent.CopyOnWriteArrayList
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

class DassRenderer(
    private val context: Context,
    private val onObjectSelected: (GameObject?) -> Unit
) : GLSurfaceView.Renderer {

    // Viewport
    var width: Int = 1080
        private set
    var height: Int = 1920
        private set

    // Camera State
    var cameraRadius: Float = 32f
    var cameraAzimuth: Float = 0f
    var cameraElevation: Float = 0.4f
    var cameraTarget: Vec3 = Vec3(0f, 12f, 0f)

    // Scene & Engine State
    var engineMode: EngineMode = EngineMode.EDITOR
    var transformMode: TransformMode = TransformMode.TRANSLATE
    var selectedObjectId: String? = null
    var planetConfig: PlanetConfig = PlanetConfig()
    var objects = CopyOnWriteArrayList<GameObject>()
    var wireframeGlobal: Boolean = false

    // Active Gizmo dragging state
    private var activeGizmoAxis: Int = 0 // 0=None, 1=X, 2=Y, 3=Z
    private var gizmoDragStartRay: Ray? = null
    private var gizmoInitialPos: Vec3 = Vec3()

    // Shader & Meshes cache
    private var shaderProgram: ShaderProgram? = null
    private var planetTerrainMesh: MeshData? = null
    private var planetOceanMesh: MeshData? = null
    private var atmosphereMesh: MeshData? = null
    private var characterMesh: MeshData? = null
    private var roverMesh: MeshData? = null
    private var spaceshipMesh: MeshData? = null
    private var speedboatMesh: MeshData? = null
    private var domeMesh: MeshData? = null
    private var treeMesh: MeshData? = null
    private var crystalMesh: MeshData? = null
    private var quadrupedMesh: MeshData? = null
    private var gizmoArrowMesh: MeshData? = null
    private var cubeMesh: MeshData? = null

    // Matrices
    private val viewMatrix = Mat4()
    private val projMatrix = Mat4()
    private val mvpMatrix = Mat4()

    private var startTimeMs: Long = System.currentTimeMillis()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        // Compile Shader Pipeline
        shaderProgram = ShaderProgram.create()

        // Generate Core Meshes
        rebuildPlanetMeshes()
        characterMesh = MeshGenerator.generateCharacterMesh()
        roverMesh = MeshGenerator.generateRoverMesh()
        spaceshipMesh = MeshGenerator.generateSpaceshipMesh()
        speedboatMesh = MeshGenerator.generateSpeedboatMesh()
        domeMesh = MeshGenerator.generateDomeMesh()
        treeMesh = MeshGenerator.generateTreeMesh()
        crystalMesh = MeshGenerator.generateCrystalMesh()
        quadrupedMesh = MeshGenerator.generateQuadrupedMesh()
        gizmoArrowMesh = MeshGenerator.generateGizmoArrow()
        cubeMesh = MeshGenerator.generateCube(1.0f)
    }

    fun rebuildPlanetMeshes() {
        planetTerrainMesh = MeshGenerator.generateSphere(
            radius = planetConfig.radius,
            rings = 40,
            sectors = 40,
            noiseScale = 0.45f
        )
        planetOceanMesh = MeshGenerator.generateSphere(
            radius = planetConfig.oceanRadius,
            rings = 36,
            sectors = 36,
            noiseScale = 0f
        )
        atmosphereMesh = MeshGenerator.generateSphere(
            radius = planetConfig.radius * 1.15f,
            rings = 24,
            sectors = 24,
            noiseScale = 0f
        )
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w
        height = h
        GLES20.glViewport(0, 0, w, h)
        val aspect = w.toFloat() / max(h.toFloat(), 1f)
        projMatrix.data.let {
            val p = Mat4.perspective(45f, aspect, 0.5f, 300f)
            System.arraycopy(p.data, 0, it, 0, 16)
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        // Deep space void clear color
        GLES20.glClearColor(0.04f, 0.06f, 0.1f, 1.0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        val shader = shaderProgram ?: return
        shader.use()

        val elapsedSec = (System.currentTimeMillis() - startTimeMs) / 1000f

        // Camera position in spherical coordinates
        val camX = cameraTarget.x + cameraRadius * cos(cameraElevation) * sin(cameraAzimuth)
        val camY = cameraTarget.y + cameraRadius * sin(cameraElevation)
        val camZ = cameraTarget.z + cameraRadius * cos(cameraElevation) * cos(cameraAzimuth)
        val camPos = Vec3(camX, camY, camZ)

        // Compute View Matrix
        val vMat = Mat4.lookAt(camPos, cameraTarget, Vec3(0f, 1f, 0f))
        System.arraycopy(vMat.data, 0, viewMatrix.data, 0, 16)

        // Set global uniforms
        GLES20.glUniform3f(shader.uViewPos, camX, camY, camZ)
        // Sun directional light vector
        GLES20.glUniform3f(shader.uLightDir, 0.6f, 0.8f, 0.5f)
        GLES20.glUniform1f(shader.uTime, elapsedSec)
        GLES20.glUniform1f(shader.uWaveSpeed, planetConfig.waveSpeed)
        GLES20.glUniform1f(shader.uWaveAmplitude, planetConfig.waveAmplitude)

        // 1. Draw Planet Terrain Sphere
        planetTerrainMesh?.let { mesh ->
            val model = Mat4.identity()
                .rotate(elapsedSec * planetConfig.rotationSpeed * 20f, 0f, 1f, 0f)
            val mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(model)

            val terrainColor = ShaderProgram.parseColor(planetConfig.terrainColorHex)
            GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
            GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, model.data, 0)
            GLES20.glUniform4fv(shader.uBaseColor, 1, terrainColor, 0)
            GLES20.glUniform1f(shader.uMetallic, 0.1f)
            GLES20.glUniform1f(shader.uRoughness, 0.7f)
            GLES20.glUniform4f(shader.uEmission, 0f, 0f, 0f, 0f)
            GLES20.glUniform1f(shader.uIsWater, 0f)
            GLES20.glUniform1f(shader.uIsAtmosphere, 0f)
            GLES20.glUniform1f(shader.uSelected, 0f)

            mesh.render(shader.aPosition, shader.aNormal, shader.aUV, wireframeGlobal)
        }

        // 2. Draw Dynamic Water / Ocean Sphere (with sine wave shader displacement)
        if (planetConfig.oceanRadius > 0.5f) {
            planetOceanMesh?.let { mesh ->
                val model = Mat4.identity()
                    .rotate(elapsedSec * planetConfig.rotationSpeed * 10f, 0f, 1f, 0f)
                val mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(model)

                val oceanColor = ShaderProgram.parseColor(planetConfig.oceanColorHex)
                GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
                GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, model.data, 0)
                GLES20.glUniform4fv(shader.uBaseColor, 1, oceanColor, 0)
                GLES20.glUniform1f(shader.uMetallic, 0.3f)
                GLES20.glUniform1f(shader.uRoughness, 0.1f)
                GLES20.glUniform4f(shader.uEmission, 0f, 0.2f, 0.4f, 0.2f)
                GLES20.glUniform1f(shader.uIsWater, 1f)
                GLES20.glUniform1f(shader.uIsAtmosphere, 0f)
                GLES20.glUniform1f(shader.uSelected, 0f)

                mesh.render(shader.aPosition, shader.aNormal, shader.aUV, wireframeGlobal)
            }
        }

        // 3. Draw Atmosphere Horizon Rim Glow
        atmosphereMesh?.let { mesh ->
            val model = Mat4.identity()
            val mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(model)

            val atmoColor = ShaderProgram.parseColor(planetConfig.atmosphereColorHex)
            GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
            GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, model.data, 0)
            GLES20.glUniform4fv(shader.uBaseColor, 1, atmoColor, 0)
            GLES20.glUniform1f(shader.uIsWater, 0f)
            GLES20.glUniform1f(shader.uIsAtmosphere, 1f)
            GLES20.glUniform1f(shader.uSelected, 0f)

            mesh.render(shader.aPosition, shader.aNormal, shader.aUV, false)
        }

        // 4. Draw Scene GameObjects
        for (obj in objects) {
            val mesh = getMeshForObject(obj)
            val isSelected = (obj.id == selectedObjectId) && (engineMode == EngineMode.EDITOR)

            val model = Mat4.identity()
                .translate(obj.position.x, obj.position.y, obj.position.z)
                .rotate(obj.rotation.x, 1f, 0f, 0f)
                .rotate(obj.rotation.y, 0f, 1f, 0f)
                .rotate(obj.rotation.z, 0f, 0f, 1f)
                .scale(obj.scale.x, obj.scale.y, obj.scale.z)

            // Animation bobbing / stride offset
            if (obj.animationState.isPlaying) {
                if (obj.animationState.clipName == "Walk" || obj.animationState.clipName == "Run") {
                    val stride = sin(elapsedSec * 8f * obj.animationState.speed) * 0.08f
                    model.translate(0f, abs(stride), 0f)
                }
            }

            val mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(model)

            val albedoColor = ShaderProgram.parseColor(obj.material.albedoHex)
            val emissColor = ShaderProgram.parseColor(obj.material.emissionHex)

            GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
            GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, model.data, 0)
            GLES20.glUniform4fv(shader.uBaseColor, 1, albedoColor, 0)
            GLES20.glUniform1f(shader.uMetallic, obj.material.metallic)
            GLES20.glUniform1f(shader.uRoughness, obj.material.roughness)
            GLES20.glUniform4f(
                shader.uEmission,
                emissColor[0], emissColor[1], emissColor[2],
                obj.material.emissionIntensity
            )
            GLES20.glUniform1f(shader.uIsWater, 0f)
            GLES20.glUniform1f(shader.uIsAtmosphere, 0f)
            GLES20.glUniform1f(shader.uSelected, if (isSelected) 1f else 0f)

            mesh.render(shader.aPosition, shader.aNormal, shader.aUV, wireframeGlobal || obj.material.wireframe)
        }

        // 5. Draw 3D Transform Gizmo if an object is selected in Editor Mode
        if (engineMode == EngineMode.EDITOR && selectedObjectId != null) {
            val selectedObj = objects.firstOrNull { it.id == selectedObjectId }
            if (selectedObj != null) {
                drawGizmo(selectedObj, shader)
            }
        }
    }

    private fun drawGizmo(selectedObj: GameObject, shader: ShaderProgram) {
        val arrow = gizmoArrowMesh ?: return
        val pos = selectedObj.position
        val gizmoScale = 1.4f

        GLES20.glDisable(GLES20.GL_DEPTH_TEST) // Draw gizmo overlay on top

        when (transformMode) {
            TransformMode.TRANSLATE -> {
                // X-Axis (Red)
                val modelX = Mat4.identity()
                    .translate(pos.x, pos.y, pos.z)
                    .rotate(-90f, 0f, 0f, 1f)
                    .scale(gizmoScale, gizmoScale, gizmoScale)
                var mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(modelX)
                GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
                GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, modelX.data, 0)
                GLES20.glUniform4f(shader.uBaseColor, 1.0f, 0.15f, 0.2f, 1.0f)
                arrow.render(shader.aPosition, shader.aNormal, shader.aUV, false)

                // Y-Axis (Green)
                val modelY = Mat4.identity()
                    .translate(pos.x, pos.y, pos.z)
                    .scale(gizmoScale, gizmoScale, gizmoScale)
                mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(modelY)
                GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
                GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, modelY.data, 0)
                GLES20.glUniform4f(shader.uBaseColor, 0.2f, 0.95f, 0.3f, 1.0f)
                arrow.render(shader.aPosition, shader.aNormal, shader.aUV, false)

                // Z-Axis (Blue)
                val modelZ = Mat4.identity()
                    .translate(pos.x, pos.y, pos.z)
                    .rotate(90f, 1f, 0f, 0f)
                    .scale(gizmoScale, gizmoScale, gizmoScale)
                mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(modelZ)
                GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
                GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, modelZ.data, 0)
                GLES20.glUniform4f(shader.uBaseColor, 0.1f, 0.6f, 1.0f, 1.0f)
                arrow.render(shader.aPosition, shader.aNormal, shader.aUV, false)
            }
            TransformMode.ROTATE, TransformMode.SCALE -> {
                // Render axial handles
                val cube = cubeMesh ?: return
                for (i in 0..2) {
                    val offset = when (i) {
                        0 -> Vec3(1.2f, 0f, 0f)
                        1 -> Vec3(0f, 1.2f, 0f)
                        else -> Vec3(0f, 0f, 1.2f)
                    }
                    val handleModel = Mat4.identity()
                        .translate(pos.x + offset.x, pos.y + offset.y, pos.z + offset.z)
                        .scale(0.22f, 0.22f, 0.22f)
                    val mvp = Mat4().multiply(projMatrix).multiply(viewMatrix).multiply(handleModel)
                    val color = when (i) {
                        0 -> floatArrayOf(1f, 0.2f, 0.2f, 1f)
                        1 -> floatArrayOf(0.2f, 0.9f, 0.2f, 1f)
                        else -> floatArrayOf(0.2f, 0.5f, 1f, 1f)
                    }
                    GLES20.glUniformMatrix4fv(shader.uMVPMatrix, 1, false, mvp.data, 0)
                    GLES20.glUniformMatrix4fv(shader.uModelMatrix, 1, false, handleModel.data, 0)
                    GLES20.glUniform4fv(shader.uBaseColor, 1, color, 0)
                    cube.render(shader.aPosition, shader.aNormal, shader.aUV, false)
                }
            }
        }

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    private fun getMeshForObject(obj: GameObject): MeshData {
        return when (obj.meshKey) {
            "character" -> characterMesh ?: cubeMesh!!
            "rover" -> roverMesh ?: cubeMesh!!
            "spaceship" -> spaceshipMesh ?: cubeMesh!!
            "speedboat" -> speedboatMesh ?: cubeMesh!!
            "dome" -> domeMesh ?: cubeMesh!!
            "tree" -> treeMesh ?: cubeMesh!!
            "crystal" -> crystalMesh ?: cubeMesh!!
            "quadruped" -> quadrupedMesh ?: cubeMesh!!
            else -> cubeMesh!!
        }
    }

    // Touch Raycasting to pick objects in 3D
    fun handleTouchTap(touchX: Float, touchY: Float) {
        val ray = RaycastHelper.screenPointToRay(
            touchX, touchY, width, height, viewMatrix, projMatrix
        )

        var closestObj: GameObject? = null
        var closestDist = Float.MAX_VALUE

        for (obj in objects) {
            val radius = max(obj.scale.x, max(obj.scale.y, obj.scale.z)) * 1.2f
            val hitT = ray.intersectSphere(obj.position, radius)
            if (hitT != null && hitT < closestDist) {
                closestDist = hitT
                closestObj = obj
            }
        }

        selectedObjectId = closestObj?.id
        onObjectSelected(closestObj)
    }

    // Touch Dragging for Gizmo manipulation
    fun handleGizmoDrag(deltaX: Float, deltaY: Float) {
        val selId = selectedObjectId ?: return
        val idx = objects.indexOfFirst { it.id == selId }
        if (idx < 0) return
        val obj = objects[idx]

        val sensitivity = 0.025f * (cameraRadius / 25f)
        val camRight = Vec3(cos(cameraAzimuth), 0f, -sin(cameraAzimuth))
        val camUp = Vec3(0f, 1f, 0f)

        when (transformMode) {
            TransformMode.TRANSLATE -> {
                val moveVec = camRight * (deltaX * sensitivity) + camUp * (-deltaY * sensitivity)
                val newPos = obj.position + moveVec
                objects[idx] = obj.copy(position = newPos)
            }
            TransformMode.ROTATE -> {
                val rotX = obj.rotation.x + deltaY * 0.5f
                val rotY = obj.rotation.y + deltaX * 0.5f
                objects[idx] = obj.copy(rotation = Vec3(rotX, rotY, obj.rotation.z))
            }
            TransformMode.SCALE -> {
                val factor = 1.0f + deltaX * 0.01f
                val clampedFactor = factor.coerceIn(0.2f, 4f)
                val newScale = Vec3(
                    (obj.scale.x * clampedFactor).coerceIn(0.2f, 20f),
                    (obj.scale.y * clampedFactor).coerceIn(0.2f, 20f),
                    (obj.scale.z * clampedFactor).coerceIn(0.2f, 20f)
                )
                objects[idx] = obj.copy(scale = newScale)
            }
        }
    }
}
