package com.example.dass.data

import com.example.dass.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class ProjectRepository(private val projectDao: ProjectDao) {

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    suspend fun getProjectById(id: Long): ProjectEntity? = projectDao.getProjectById(id)

    suspend fun insertProject(project: ProjectEntity): Long = projectDao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)

    suspend fun deleteProjectById(id: Long) = projectDao.deleteProjectById(id)

    suspend fun initializeDefaultTemplatesIfNeeded() {
        val existing = allProjects.firstOrNull()
        if (existing.isNullOrEmpty()) {
            // Seed 1: Ocean Oasis (The flagship procedural water planet)
            val oceanPlanet = PlanetConfig(
                radius = 12f,
                oceanRadius = 12.25f,
                oceanColorHex = "#0077B6",
                terrainColorHex = "#2A9D8F",
                atmosphereColorHex = "#00E5FF",
                waveSpeed = 1.4f,
                waveAmplitude = 0.2f
            )
            val oceanObjects = listOf(
                GameObject(
                    name = "Astronaut Hero",
                    type = ObjectType.CHARACTER,
                    position = Vec3(0f, 12.4f, 0f),
                    scale = Vec3(1f, 1.8f, 1f),
                    material = MaterialData(albedoHex = "#00E5FF", metallic = 0.3f, roughness = 0.3f),
                    meshKey = "character",
                    animationState = AnimationState("Idle", 1.0f)
                ),
                GameObject(
                    name = "All-Terrain Buggy",
                    type = ObjectType.VEHICLE,
                    position = Vec3(2.5f, 12.35f, 2.0f),
                    scale = Vec3(1.6f, 1.0f, 2.2f),
                    material = MaterialData(albedoHex = "#FF9100", metallic = 0.6f, roughness = 0.3f),
                    meshKey = "rover",
                    vehicleData = VehicleData(VehicleType.WHEELED, maxSpeed = 22f, acceleration = 10f)
                ),
                GameObject(
                    name = "Atmospheric Skimmer",
                    type = ObjectType.VEHICLE,
                    position = Vec3(-3.5f, 14.5f, 1.5f),
                    scale = Vec3(2.0f, 0.8f, 2.8f),
                    material = MaterialData(albedoHex = "#7C4DFF", metallic = 0.8f, roughness = 0.2f, emissionHex = "#00E5FF", emissionIntensity = 0.8f),
                    meshKey = "spaceship",
                    vehicleData = VehicleData(VehicleType.FLYING, maxSpeed = 35f, acceleration = 18f)
                ),
                GameObject(
                    name = "Speedboat Cruiser",
                    type = ObjectType.VEHICLE,
                    position = Vec3(4.0f, 12.2f, -3.0f),
                    scale = Vec3(1.4f, 0.9f, 2.5f),
                    material = MaterialData(albedoHex = "#00F5D4", metallic = 0.5f, roughness = 0.2f),
                    meshKey = "speedboat",
                    vehicleData = VehicleData(VehicleType.FLOATING, maxSpeed = 20f, acceleration = 12f)
                ),
                GameObject(
                    name = "Sci-Fi Colony Dome",
                    type = ObjectType.BUILDING,
                    position = Vec3(-2.8f, 12.1f, -2.8f),
                    scale = Vec3(3.5f, 2.5f, 3.5f),
                    material = MaterialData(albedoHex = "#4CC9F0", metallic = 0.9f, roughness = 0.1f, emissionHex = "#4CC9F0", emissionIntensity = 0.4f),
                    meshKey = "dome"
                ),
                GameObject(
                    name = "Alien Palm Tree",
                    type = ObjectType.NATURE,
                    position = Vec3(1.2f, 12.3f, -1.8f),
                    scale = Vec3(1.2f, 2.2f, 1.2f),
                    material = MaterialData(albedoHex = "#06D6A0", metallic = 0.1f, roughness = 0.6f),
                    meshKey = "tree"
                ),
                GameObject(
                    name = "Cyber Hound",
                    type = ObjectType.ANIMAL,
                    position = Vec3(-1.0f, 12.35f, 1.8f),
                    scale = Vec3(0.9f, 0.9f, 1.4f),
                    material = MaterialData(albedoHex = "#E76F51", metallic = 0.4f, roughness = 0.4f),
                    meshKey = "quadruped",
                    animationState = AnimationState("Idle", 1.0f)
                )
            )

            insertProject(
                ProjectEntity(
                    name = "Ocean Oasis",
                    presetName = PlanetPreset.OCEAN_WORLD.name,
                    targetFps = 60,
                    renderQuality = RenderQuality.MEDIUM.name,
                    exportPackage = "com.dass.game.ocean_oasis",
                    sceneJson = SceneSerializer.serializeScene(
                        SceneBundle(oceanPlanet, oceanObjects, SettingsConfig())
                    )
                )
            )

            // Seed 2: Cyber Dunes
            val cyberPlanet = PlanetConfig(
                radius = 12f,
                oceanRadius = 11.5f,
                oceanColorHex = "#7209B7",
                terrainColorHex = "#F72585",
                atmosphereColorHex = "#4CC9F0",
                waveSpeed = 0.8f,
                waveAmplitude = 0.05f
            )
            val cyberObjects = listOf(
                GameObject(
                    name = "Desert Stalker",
                    type = ObjectType.CHARACTER,
                    position = Vec3(0f, 12.4f, 0f),
                    scale = Vec3(1f, 1.8f, 1f),
                    material = MaterialData(albedoHex = "#F72585", metallic = 0.5f, roughness = 0.2f),
                    meshKey = "character"
                ),
                GameObject(
                    name = "Dune Raider Rover",
                    type = ObjectType.VEHICLE,
                    position = Vec3(3f, 12.35f, 0f),
                    scale = Vec3(1.8f, 1.1f, 2.4f),
                    material = MaterialData(albedoHex = "#4CC9F0", metallic = 0.7f, roughness = 0.3f),
                    meshKey = "rover",
                    vehicleData = VehicleData(VehicleType.WHEELED, maxSpeed = 26f, acceleration = 12f)
                ),
                GameObject(
                    name = "Neon Crystal Spire",
                    type = ObjectType.NATURE,
                    position = Vec3(-2.5f, 12.3f, 2.5f),
                    scale = Vec3(1.2f, 3.5f, 1.2f),
                    material = MaterialData(albedoHex = "#7209B7", metallic = 0.9f, roughness = 0.1f, emissionHex = "#F72585", emissionIntensity = 1.0f),
                    meshKey = "crystal"
                )
            )

            insertProject(
                ProjectEntity(
                    name = "Cyber Dunes",
                    presetName = PlanetPreset.CYBER_DUNES.name,
                    targetFps = 60,
                    renderQuality = RenderQuality.ULTRA.name,
                    exportPackage = "com.dass.game.cyber_dunes",
                    sceneJson = SceneSerializer.serializeScene(
                        SceneBundle(cyberPlanet, cyberObjects, SettingsConfig())
                    )
                )
            )

            // Seed 3: Low-Poly Moon
            val moonPlanet = PlanetConfig(
                radius = 12f,
                oceanRadius = 0f,
                oceanColorHex = "#1D2D44",
                terrainColorHex = "#747F8F",
                atmosphereColorHex = "#5E6D82",
                waveSpeed = 0f,
                waveAmplitude = 0f
            )
            val moonObjects = listOf(
                GameObject(
                    name = "Lunar Scout",
                    type = ObjectType.CHARACTER,
                    position = Vec3(0f, 12.4f, 0f),
                    scale = Vec3(1f, 1.8f, 1f),
                    material = MaterialData(albedoHex = "#FFFFFF", metallic = 0.1f, roughness = 0.5f),
                    meshKey = "character"
                ),
                GameObject(
                    name = "Lunar Habitat",
                    type = ObjectType.BUILDING,
                    position = Vec3(-2.0f, 12.2f, -2.0f),
                    scale = Vec3(3.2f, 2.0f, 3.2f),
                    material = MaterialData(albedoHex = "#CBD5E1", metallic = 0.8f, roughness = 0.3f),
                    meshKey = "dome"
                )
            )

            insertProject(
                ProjectEntity(
                    name = "Low-Poly Moon Base",
                    presetName = PlanetPreset.LOW_POLY_MOON.name,
                    targetFps = 60,
                    renderQuality = RenderQuality.MEDIUM.name,
                    exportPackage = "com.dass.game.moon_base",
                    sceneJson = SceneSerializer.serializeScene(
                        SceneBundle(moonPlanet, moonObjects, SettingsConfig(gravity = -3.7f))
                    )
                )
            )
        }
    }
}
