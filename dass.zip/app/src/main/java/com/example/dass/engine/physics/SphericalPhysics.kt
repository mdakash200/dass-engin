package com.example.dass.engine.physics

import com.example.dass.model.*
import kotlin.math.*

class SphericalPhysics(
    var gravity: Float = -9.8f,
    var planetRadius: Float = 12.0f,
    var oceanRadius: Float = 12.2f,
    var isSpherical: Boolean = true
) {
    // Dynamic physics state for active character
    var playerVelocity: Vec3 = Vec3(0f, 0f, 0f)
    var isGrounded: Boolean = false
    var currentSpeed: Float = 0f
    var playerHeadingRad: Float = 0f

    // Vehicle physics state
    var activeVehicle: GameObject? = null
    var vehicleVelocity: Vec3 = Vec3(0f, 0f, 0f)
    var vehicleSpeed: Float = 0f
    var vehicleSteerAngle: Float = 0f

    fun updateCharacter(
        character: GameObject,
        moveInput: Vec3, // x = strafe, z = forward (-1 to 1)
        isSprint: Boolean,
        jumpTriggered: Boolean,
        cameraYaw: Float,
        deltaTime: Float
    ): GameObject {
        val pos = character.position
        val normal = if (isSpherical) pos.normalized() else Vec3(0f, 1f, 0f)

        // Calculate surface Tangent space (East and North vectors on the sphere)
        val arbitraryUp = if (abs(normal.y) > 0.95f) Vec3(0f, 0f, 1f) else Vec3(0f, 1f, 0f)
        val tangentX = crossProduct(arbitraryUp, normal).normalized()
        val tangentZ = crossProduct(normal, tangentX).normalized()

        // Rotate tangent directions based on camera yaw
        val cosY = cos(cameraYaw)
        val sinY = sin(cameraYaw)
        val forwardDir = (tangentZ * cosY - tangentX * sinY).normalized()
        val rightDir = (tangentX * cosY + tangentZ * sinY).normalized()

        // Determine target move direction
        val moveDir = (rightDir * moveInput.x + forwardDir * moveInput.z)
        val targetSpeed = if (isSprint) 10.0f else 5.0f

        val effectiveMove = if (moveDir.length() > 0.05f) {
            moveDir.normalized() * targetSpeed
        } else {
            Vec3(0f, 0f, 0f)
        }

        // Apply Gravity
        val gravForce = if (isSpherical) normal * gravity else Vec3(0f, gravity, 0f)
        playerVelocity = playerVelocity + gravForce * deltaTime

        // Handle Jump
        if (jumpTriggered && isGrounded) {
            val jumpImpulse = normal * 8.5f
            playerVelocity = playerVelocity + jumpImpulse
            isGrounded = false
        }

        // Integrate Position
        var newPos = pos + (effectiveMove + playerVelocity) * deltaTime

        // Planetary collision detection
        val effectiveSurfaceRadius = max(planetRadius + 0.9f, oceanRadius + 0.2f)
        val distToCenter = newPos.length()

        if (distToCenter <= effectiveSurfaceRadius) {
            // Hit ground / ocean surface
            newPos = newPos.normalized() * effectiveSurfaceRadius
            playerVelocity = Vec3(0f, 0f, 0f)
            isGrounded = true
        } else {
            isGrounded = false
        }

        currentSpeed = effectiveMove.length()

        // Determine animation clip
        val clipName = when {
            !isGrounded -> "Jump"
            currentSpeed > 6.0f -> "Run"
            currentSpeed > 0.2f -> "Walk"
            else -> "Idle"
        }

        val animSpeed = when (clipName) {
            "Run" -> 1.5f
            "Walk" -> 1.0f
            else -> 0.8f
        }

        // Calculate rotation Euler angles aligned with planet sphere
        val yawDeg = Math.toDegrees(atan2(effectiveMove.x.toDouble(), effectiveMove.z.toDouble())).toFloat()
        val pitchDeg = Math.toDegrees(asin(normal.y.toDouble())).toFloat()
        val rollDeg = Math.toDegrees(atan2(normal.x.toDouble(), normal.z.toDouble())).toFloat()

        return character.copy(
            position = newPos,
            rotation = Vec3(pitchDeg, yawDeg, rollDeg),
            animationState = AnimationState(clipName, animSpeed, true)
        )
    }

    fun updateVehicle(
        vehicle: GameObject,
        throttleInput: Float, // -1 (reverse) to 1 (forward)
        steerInput: Float,    // -1 (left) to 1 (right)
        boostActive: Boolean,
        deltaTime: Float
    ): GameObject {
        val vData = vehicle.vehicleData ?: return vehicle
        val pos = vehicle.position
        val normal = if (isSpherical) pos.normalized() else Vec3(0f, 1f, 0f)

        val maxSpd = if (boostActive) vData.maxSpeed * 1.6f else vData.maxSpeed
        val targetVel = throttleInput * maxSpd

        vehicleSpeed += (targetVel - vehicleSpeed) * vData.acceleration * 0.1f * deltaTime
        vehicleSteerAngle += (steerInput * 45f - vehicleSteerAngle) * 5f * deltaTime

        // Vehicle forward orientation on planet
        val arbitraryUp = if (abs(normal.y) > 0.95f) Vec3(0f, 0f, 1f) else Vec3(0f, 1f, 0f)
        val forwardTang = crossProduct(normal, arbitraryUp).normalized()

        val forwardMove = forwardTang * vehicleSpeed * deltaTime
        var newPos = pos + forwardMove

        val surfaceRadius = when (vData.type) {
            VehicleType.FLOATING -> oceanRadius + 0.2f + sin(System.currentTimeMillis() * 0.003f) * 0.1f
            VehicleType.FLYING -> planetRadius + 4.5f
            VehicleType.WHEELED -> max(planetRadius + 0.5f, oceanRadius + 0.3f)
        }

        val currentDist = newPos.length()
        if (currentDist < surfaceRadius || vData.type != VehicleType.FLYING) {
            newPos = newPos.normalized() * surfaceRadius
        }

        val updatedVData = vData.copy(
            currentSpeed = vehicleSpeed
        )

        return vehicle.copy(
            position = newPos,
            rotation = Vec3(vehicle.rotation.x, vehicle.rotation.y + vehicleSteerAngle * deltaTime * 20f, vehicle.rotation.z),
            vehicleData = updatedVData
        )
    }

    private fun crossProduct(a: Vec3, b: Vec3): Vec3 {
        return Vec3(
            a.y * b.z - a.z * b.y,
            a.z * b.x - a.x * b.z,
            a.x * b.y - a.y * b.x
        )
    }
}
