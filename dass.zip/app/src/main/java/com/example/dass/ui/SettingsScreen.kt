package com.example.dass.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.dass.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: DassViewModel,
    modifier: Modifier = Modifier
) {
    val settingsConfig by viewModel.settingsConfig.collectAsStateWithLifecycle()
    var currentTab by remember { mutableIntStateOf(0) } // 0=Graphics, 1=Audio, 2=Physics, 3=Export

    BackHandler {
        viewModel.navigateTo(DassScreen.HOME)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(VoidBlack)
            .windowInsetsPadding(WindowInsets.statusBars),
        containerColor = VoidBlack,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Engine Settings",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(DassScreen.HOME) }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = VoidBlack)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Row
            TabRow(
                selectedTabIndex = currentTab,
                containerColor = SurfaceDark,
                contentColor = CyanNeon,
                divider = { Divider(color = SurfaceBorder) }
            ) {
                Tab(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    text = { Text("Graphics", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = currentTab == 1,
                    onClick = { currentTab = 1 },
                    text = { Text("Audio", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    text = { Text("Physics", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = currentTab == 3,
                    onClick = { currentTab = 3 },
                    text = { Text("Export", fontWeight = FontWeight.Bold) }
                )
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (currentTab) {
                    0 -> {
                        // GRAPHICS SETTINGS
                        item {
                            SettingsCard(title = "Target Frame Rate (FPS)") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    TargetFps.values().forEach { fps ->
                                        val isSel = settingsConfig.targetFps == fps
                                        OutlinedButton(
                                            onClick = { viewModel.updateSettings(settingsConfig.copy(targetFps = fps)) },
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (isSel) CyanNeon else SurfaceCard,
                                                contentColor = if (isSel) VoidBlack else TextPrimary
                                            ),
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSel) CyanNeon else SurfaceBorder
                                            )
                                        ) {
                                            Text("${fps.fps} FPS", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            SettingsCard(title = "Rendering Quality Profile") {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    RenderQuality.values().forEach { qual ->
                                        val isSel = settingsConfig.renderQuality == qual
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSel) SurfaceElevated else SurfaceCard)
                                                .border(1.dp, if (isSel) CyanNeon else SurfaceBorder, RoundedCornerShape(8.dp))
                                                .clickable {
                                                    viewModel.updateSettings(settingsConfig.copy(renderQuality = qual))
                                                }
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            RadioButton(
                                                selected = isSel,
                                                onClick = { viewModel.updateSettings(settingsConfig.copy(renderQuality = qual)) },
                                                colors = RadioButtonDefaults.colors(selectedColor = CyanNeon)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(qual.label, color = TextPrimary, fontWeight = FontWeight.Bold)
                                                Text(
                                                    "Shadow Map: ${qual.shadowRes}px · Max Lights: ${qual.maxLights}",
                                                    color = TextMuted,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            SettingsCard(title = "Post-Processing & Visual FX") {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Dynamic Shadow Maps", color = TextPrimary)
                                    Switch(
                                        checked = settingsConfig.shadowEnabled,
                                        onCheckedChange = { viewModel.updateSettings(settingsConfig.copy(shadowEnabled = it)) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CyanNeon)
                                    )
                                }
                                Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Atmospheric Bloom Effect", color = TextPrimary)
                                    Switch(
                                        checked = settingsConfig.bloomEnabled,
                                        onCheckedChange = { viewModel.updateSettings(settingsConfig.copy(bloomEnabled = it)) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CyanNeon)
                                    )
                                }
                            }
                        }
                    }

                    1 -> {
                        // SOUND SETTINGS
                        item {
                            SettingsCard(title = "Master & Channel Volume") {
                                // Master Volume
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Master Audio", color = TextPrimary)
                                        Text("${(settingsConfig.masterVolume * 100).toInt()}%", color = CyanNeon)
                                    }
                                    Slider(
                                        value = settingsConfig.masterVolume,
                                        onValueChange = { viewModel.updateSettings(settingsConfig.copy(masterVolume = it)) },
                                        colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon)
                                    )
                                }

                                // SFX Volume
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("SFX Sound Effects", color = TextPrimary)
                                        Text("${(settingsConfig.sfxVolume * 100).toInt()}%", color = CyanNeon)
                                    }
                                    Slider(
                                        value = settingsConfig.sfxVolume,
                                        onValueChange = { viewModel.updateSettings(settingsConfig.copy(sfxVolume = it)) },
                                        colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon)
                                    )
                                }

                                // BGM Volume
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("BGM Planetary Ambience", color = TextPrimary)
                                        Text("${(settingsConfig.bgmVolume * 100).toInt()}%", color = CyanNeon)
                                    }
                                    Slider(
                                        value = settingsConfig.bgmVolume,
                                        onValueChange = { viewModel.updateSettings(settingsConfig.copy(bgmVolume = it)) },
                                        colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon)
                                    )
                                }
                            }
                        }
                    }

                    2 -> {
                        // PHYSICS ENGINE SETTINGS
                        item {
                            SettingsCard(title = "World Gravity & Dynamics") {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Gravity Force", color = TextPrimary)
                                        Text("${String.format("%.1f", settingsConfig.gravity)} m/s²", color = CyanNeon)
                                    }
                                    Slider(
                                        value = settingsConfig.gravity,
                                        onValueChange = { viewModel.updateSettings(settingsConfig.copy(gravity = it)) },
                                        valueRange = -25f..0f,
                                        colors = SliderDefaults.colors(thumbColor = CyanNeon, activeTrackColor = CyanNeon)
                                    )
                                }

                                Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Spherical Center Gravity", color = TextPrimary)
                                        Text("Pulls entities toward planet core (0,0,0)", color = TextMuted, fontSize = 11.sp)
                                    }
                                    Switch(
                                        checked = settingsConfig.sphericalGravity,
                                        onCheckedChange = { viewModel.updateSettings(settingsConfig.copy(sphericalGravity = it)) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CyanNeon)
                                    )
                                }

                                Divider(color = SurfaceBorder, modifier = Modifier.padding(vertical = 8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Continuous Collision (CCD)", color = TextPrimary)
                                        Text("Prevents fast vehicles tunneling through planet", color = TextMuted, fontSize = 11.sp)
                                    }
                                    Switch(
                                        checked = settingsConfig.collisionPrecisionHigh,
                                        onCheckedChange = { viewModel.updateSettings(settingsConfig.copy(collisionPrecisionHigh = it)) },
                                        colors = SwitchDefaults.colors(checkedThumbColor = CyanNeon)
                                    )
                                }
                            }
                        }
                    }

                    3 -> {
                        // EXPORT CONFIG
                        item {
                            SettingsCard(title = "APK Runtime Export Configuration") {
                                OutlinedTextField(
                                    value = settingsConfig.defaultPackagePrefix,
                                    onValueChange = { viewModel.updateSettings(settingsConfig.copy(defaultPackagePrefix = it)) },
                                    label = { Text("Default Package Name Prefix") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyanNeon,
                                        unfocusedBorderColor = SurfaceBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "RUNTIME PERMISSIONS CHECKLIST",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontWeight = FontWeight.Bold)
                                )

                                val permissionList = listOf(
                                    "INTERNET" to "Network multiplayer & cloud asset streaming",
                                    "VIBRATE" to "Haptic feedback for controller & vehicle crash",
                                    "CAMERA" to "AR portal & camera background tracking",
                                    "RECORD_AUDIO" to "Spatial voice chat & audio reactive physics"
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    permissionList.forEach { (perm, desc) ->
                                        val isChecked = settingsConfig.exportPermissions.contains(perm)
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(SurfaceCard)
                                                .clickable {
                                                    val newPerms = if (isChecked) {
                                                        settingsConfig.exportPermissions - perm
                                                    } else {
                                                        settingsConfig.exportPermissions + perm
                                                    }
                                                    viewModel.updateSettings(settingsConfig.copy(exportPermissions = newPerms))
                                                }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = isChecked,
                                                onCheckedChange = { checked ->
                                                    val newPerms = if (checked) {
                                                        settingsConfig.exportPermissions + perm
                                                    } else {
                                                        settingsConfig.exportPermissions - perm
                                                    }
                                                    viewModel.updateSettings(settingsConfig.copy(exportPermissions = newPerms))
                                                },
                                                colors = CheckboxDefaults.colors(checkedColor = CyanNeon)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Text(perm, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                Text(desc, color = TextMuted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun SettingsCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = CyanNeon
                )
            )
            content()
        }
    }
}
