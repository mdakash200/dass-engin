package com.example.dass.engine.graphics

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.*

class MeshData(
    val vertexBuffer: FloatBuffer,
    val normalBuffer: FloatBuffer,
    val uvBuffer: FloatBuffer,
    val indexBuffer: ShortBuffer,
    val indexCount: Int
) {
    fun render(
        posHandle: Int,
        normHandle: Int,
        uvHandle: Int,
        wireframe: Boolean = false
    ) {
        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(posHandle)
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, vertexBuffer)

        if (normHandle >= 0) {
            normalBuffer.position(0)
            GLES20.glEnableVertexAttribArray(normHandle)
            GLES20.glVertexAttribPointer(normHandle, 3, GLES20.GL_FLOAT, false, 0, normalBuffer)
        }

        if (uvHandle >= 0) {
            uvBuffer.position(0)
            GLES20.glEnableVertexAttribArray(uvHandle)
            GLES20.glVertexAttribPointer(uvHandle, 2, GLES20.GL_FLOAT, false, 0, uvBuffer)
        }

        indexBuffer.position(0)
        val mode = if (wireframe) GLES20.GL_LINES else GLES20.GL_TRIANGLES
        GLES20.glDrawElements(mode, indexCount, GLES20.GL_UNSIGNED_SHORT, indexBuffer)

        GLES20.glDisableVertexAttribArray(posHandle)
        if (normHandle >= 0) GLES20.glDisableVertexAttribArray(normHandle)
        if (uvHandle >= 0) GLES20.glDisableVertexAttribArray(uvHandle)
    }

    companion object {
        fun createFromArrays(
            positions: FloatArray,
            normals: FloatArray,
            uvs: FloatArray,
            indices: ShortArray
        ): MeshData {
            val vb = ByteBuffer.allocateDirect(positions.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            vb.put(positions).position(0)

            val nb = ByteBuffer.allocateDirect(normals.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            nb.put(normals).position(0)

            val ub = ByteBuffer.allocateDirect(uvs.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            ub.put(uvs).position(0)

            val ib = ByteBuffer.allocateDirect(indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
            ib.put(indices).position(0)

            return MeshData(vb, nb, ub, ib, indices.size)
        }
    }
}

object MeshGenerator {

    // Procedural UV Sphere with terrain elevation noise
    fun generateSphere(radius: Float, rings: Int = 32, sectors: Int = 32, noiseScale: Float = 0f): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val R = 1f / (rings - 1).toFloat()
        val S = 1f / (sectors - 1).toFloat()

        for (r in 0 until rings) {
            val v = r * R
            val theta = v * Math.PI.toFloat()
            val sinTheta = sin(theta)
            val cosTheta = cos(theta)

            for (s in 0 until sectors) {
                val u = s * S
                val phi = u * 2f * Math.PI.toFloat()
                val sinPhi = sin(phi)
                val cosPhi = cos(phi)

                val nx = cosPhi * sinTheta
                val ny = cosTheta
                val nz = sinPhi * sinTheta

                // Procedural terrain elevation noise
                val noise = if (noiseScale > 0f) {
                    val n1 = sin(nx * 4f) * cos(nz * 4f) * 0.4f
                    val n2 = sin(nx * 8f + ny * 6f) * 0.2f
                    (n1 + n2) * noiseScale
                } else 0f

                val rFinal = radius + noise

                positions.add(nx * rFinal)
                positions.add(ny * rFinal)
                positions.add(nz * rFinal)

                normals.add(nx)
                normals.add(ny)
                normals.add(nz)

                uvs.add(u)
                uvs.add(v)
            }
        }

        for (r in 0 until rings - 1) {
            for (s in 0 until sectors - 1) {
                val i0 = (r * sectors + s).toShort()
                val i1 = (r * sectors + (s + 1)).toShort()
                val i2 = ((r + 1) * sectors + (s + 1)).toShort()
                val i3 = ((r + 1) * sectors + s).toShort()

                indices.add(i0)
                indices.add(i1)
                indices.add(i2)

                indices.add(i0)
                indices.add(i2)
                indices.add(i3)
            }
        }

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Low-poly Humanoid Character (Astronaut / Explorer)
    fun generateCharacterMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                // Front
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                // Back
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                // Top
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                // Bottom
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                // Right
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                // Left
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i])
                positions.add(boxVerts[i + 1])
                positions.add(boxVerts[i + 2])

                normals.add(boxNorms[i])
                normals.add(boxNorms[i + 1])
                normals.add(boxNorms[i + 2])

                uvs.add(0.5f)
                uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b)
                indices.add((b + 1).toShort())
                indices.add((b + 2).toShort())
                indices.add(b)
                indices.add((b + 2).toShort())
                indices.add((b + 3).toShort())
            }
        }

        // Torso
        addBox(0f, 0.95f, 0f, 0.6f, 0.7f, 0.35f)
        // Head / Helmet
        addBox(0f, 1.55f, 0f, 0.45f, 0.45f, 0.45f)
        // Visor
        addBox(0f, 1.58f, 0.22f, 0.35f, 0.22f, 0.1f)
        // Left Leg
        addBox(-0.18f, 0.32f, 0f, 0.22f, 0.65f, 0.24f)
        // Right Leg
        addBox(0.18f, 0.32f, 0f, 0.22f, 0.65f, 0.24f)
        // Left Arm
        addBox(-0.42f, 0.95f, 0f, 0.2f, 0.65f, 0.22f)
        // Right Arm
        addBox(0.42f, 0.95f, 0f, 0.2f, 0.65f, 0.22f)
        // Jetpack / Backpack
        addBox(0f, 1.05f, -0.24f, 0.45f, 0.5f, 0.2f)

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Wheeled Buggy / Rover Vehicle Mesh
    fun generateRoverMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i]); positions.add(boxVerts[i + 1]); positions.add(boxVerts[i + 2])
                normals.add(boxNorms[i]); normals.add(boxNorms[i + 1]); normals.add(boxNorms[i + 2])
                uvs.add(0.5f); uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b); indices.add((b + 1).toShort()); indices.add((b + 2).toShort())
                indices.add(b); indices.add((b + 2).toShort()); indices.add((b + 3).toShort())
            }
        }

        // Chassis body
        addBox(0f, 0.45f, 0f, 1.4f, 0.45f, 2.0f)
        // Cabin cockpit
        addBox(0f, 0.85f, -0.1f, 1.0f, 0.45f, 1.1f)
        // Windshield
        addBox(0f, 0.88f, 0.48f, 0.85f, 0.35f, 0.15f)
        // Roll cage / antenna
        addBox(0.4f, 1.25f, -0.4f, 0.08f, 0.6f, 0.08f)
        // 4 Wheels
        addBox(-0.85f, 0.35f, 0.65f, 0.35f, 0.65f, 0.65f) // Front-left
        addBox(0.85f, 0.35f, 0.65f, 0.35f, 0.65f, 0.65f)  // Front-right
        addBox(-0.85f, 0.35f, -0.65f, 0.35f, 0.65f, 0.65f) // Rear-left
        addBox(0.85f, 0.35f, -0.65f, 0.35f, 0.65f, 0.65f)  // Rear-right

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Spaceship / Flying Vehicle Mesh
    fun generateSpaceshipMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i]); positions.add(boxVerts[i + 1]); positions.add(boxVerts[i + 2])
                normals.add(boxNorms[i]); normals.add(boxNorms[i + 1]); normals.add(boxNorms[i + 2])
                uvs.add(0.5f); uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b); indices.add((b + 1).toShort()); indices.add((b + 2).toShort())
                indices.add(b); indices.add((b + 2).toShort()); indices.add((b + 3).toShort())
            }
        }

        // Fuselage
        addBox(0f, 0.4f, 0f, 0.9f, 0.45f, 2.6f)
        // Cockpit canopy
        addBox(0f, 0.72f, 0.3f, 0.6f, 0.35f, 1.2f)
        // Delta Wings
        addBox(0f, 0.35f, -0.2f, 3.2f, 0.08f, 1.4f)
        // Winglets
        addBox(-1.55f, 0.65f, -0.2f, 0.08f, 0.6f, 0.8f)
        addBox(1.55f, 0.65f, -0.2f, 0.08f, 0.6f, 0.8f)
        // Dual Plasma Thrusters
        addBox(-0.35f, 0.4f, -1.35f, 0.32f, 0.32f, 0.5f)
        addBox(0.35f, 0.4f, -1.35f, 0.32f, 0.32f, 0.5f)

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Floating Speedboat / Hovercraft Mesh
    fun generateSpeedboatMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i]); positions.add(boxVerts[i + 1]); positions.add(boxVerts[i + 2])
                normals.add(boxNorms[i]); normals.add(boxNorms[i + 1]); normals.add(boxNorms[i + 2])
                uvs.add(0.5f); uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b); indices.add((b + 1).toShort()); indices.add((b + 2).toShort())
                indices.add(b); indices.add((b + 2).toShort()); indices.add((b + 3).toShort())
            }
        }

        // Hull
        addBox(0f, 0.25f, 0f, 1.4f, 0.4f, 2.4f)
        // Bow point
        addBox(0f, 0.32f, 1.3f, 0.9f, 0.35f, 0.6f)
        // Windshield
        addBox(0f, 0.65f, 0.4f, 1.1f, 0.35f, 0.15f)
        // Outboard Turbine Motor
        addBox(0f, 0.45f, -1.3f, 0.5f, 0.6f, 0.45f)

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Geodesic Colony Dome
    fun generateDomeMesh(): MeshData {
        return generateSphere(radius = 1.8f, rings = 16, sectors = 24, noiseScale = 0f)
    }

    // Tree / Alien Flora
    fun generateTreeMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i]); positions.add(boxVerts[i + 1]); positions.add(boxVerts[i + 2])
                normals.add(boxNorms[i]); normals.add(boxNorms[i + 1]); normals.add(boxNorms[i + 2])
                uvs.add(0.5f); uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b); indices.add((b + 1).toShort()); indices.add((b + 2).toShort())
                indices.add(b); indices.add((b + 2).toShort()); indices.add((b + 3).toShort())
            }
        }

        // Trunk
        addBox(0f, 0.9f, 0f, 0.28f, 1.8f, 0.28f)
        // Foliage lower tier
        addBox(0f, 1.7f, 0f, 1.6f, 0.6f, 1.6f)
        // Foliage middle tier
        addBox(0f, 2.2f, 0f, 1.2f, 0.6f, 1.2f)
        // Foliage top spire
        addBox(0f, 2.7f, 0f, 0.7f, 0.6f, 0.7f)

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Faceted Crystal Spire
    fun generateCrystalMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        val sides = 6
        val height = 2.8f
        val radius = 0.6f

        // Center bottom & top vertices
        val botIdx = (positions.size / 3).toShort()
        positions.add(0f); positions.add(0f); positions.add(0f)
        normals.add(0f); normals.add(-1f); normals.add(0f)
        uvs.add(0.5f); uvs.add(0f)

        val topIdx = (positions.size / 3).toShort()
        positions.add(0f); positions.add(height); positions.add(0f)
        normals.add(0f); normals.add(1f); normals.add(0f)
        uvs.add(0.5f); uvs.add(1f)

        val midBase = (positions.size / 3).toShort()
        for (i in 0 until sides) {
            val angle = i * 2f * Math.PI.toFloat() / sides
            val x = cos(angle) * radius
            val z = sin(angle) * radius
            positions.add(x); positions.add(height * 0.45f); positions.add(z)
            normals.add(cos(angle)); normals.add(0.2f); normals.add(sin(angle))
            uvs.add(i.toFloat() / sides); uvs.add(0.5f)
        }

        for (i in 0 until sides) {
            val nxt = ((i + 1) % sides).toShort()
            val c1 = (midBase + i).toShort()
            val c2 = (midBase + nxt).toShort()

            // Bottom pyramid
            indices.add(botIdx); indices.add(c2); indices.add(c1)
            // Top pyramid
            indices.add(topIdx); indices.add(c1); indices.add(c2)
        }

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Quadruped Animal Mesh
    fun generateQuadrupedMesh(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        fun addBox(cx: Float, cy: Float, cz: Float, sx: Float, sy: Float, sz: Float) {
            val baseIdx = (positions.size / 3).toShort()
            val x0 = cx - sx / 2f; val x1 = cx + sx / 2f
            val y0 = cy - sy / 2f; val y1 = cy + sy / 2f
            val z0 = cz - sz / 2f; val z1 = cz + sz / 2f

            val boxVerts = floatArrayOf(
                x0, y0, z1,  x1, y0, z1,  x1, y1, z1,  x0, y1, z1,
                x1, y0, z0,  x0, y0, z0,  x0, y1, z0,  x1, y1, z0,
                x0, y1, z1,  x1, y1, z1,  x1, y1, z0,  x0, y1, z0,
                x0, y0, z0,  x1, y0, z0,  x1, y0, z1,  x0, y0, z1,
                x1, y0, z1,  x1, y0, z0,  x1, y1, z0,  x1, y1, z1,
                x0, y0, z0,  x0, y0, z1,  x0, y1, z1,  x0, y1, z0
            )

            val boxNorms = floatArrayOf(
                0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,  0f, 0f, 1f,
                0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
                0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,  0f, 1f, 0f,
                0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f,
                1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,  1f, 0f, 0f,
                -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f
            )

            for (i in boxVerts.indices step 3) {
                positions.add(boxVerts[i]); positions.add(boxVerts[i + 1]); positions.add(boxVerts[i + 2])
                normals.add(boxNorms[i]); normals.add(boxNorms[i + 1]); normals.add(boxNorms[i + 2])
                uvs.add(0.5f); uvs.add(0.5f)
            }

            for (f in 0 until 6) {
                val b = (baseIdx + f * 4).toShort()
                indices.add(b); indices.add((b + 1).toShort()); indices.add((b + 2).toShort())
                indices.add(b); indices.add((b + 2).toShort()); indices.add((b + 3).toShort())
            }
        }

        // Body torso
        addBox(0f, 0.65f, 0f, 0.5f, 0.45f, 1.1f)
        // Neck & Head
        addBox(0f, 0.95f, 0.55f, 0.35f, 0.38f, 0.45f)
        // Snout
        addBox(0f, 0.88f, 0.82f, 0.22f, 0.2f, 0.3f)
        // 4 Legs
        addBox(-0.2f, 0.25f, 0.4f, 0.15f, 0.55f, 0.16f)
        addBox(0.2f, 0.25f, 0.4f, 0.15f, 0.55f, 0.16f)
        addBox(-0.2f, 0.25f, -0.4f, 0.15f, 0.55f, 0.16f)
        addBox(0.2f, 0.25f, -0.4f, 0.15f, 0.55f, 0.16f)
        // Tail
        addBox(0f, 0.72f, -0.65f, 0.1f, 0.12f, 0.4f)

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // 3D Transform Gizmo: Translation Arrow (Cone + Shaft)
    fun generateGizmoArrow(): MeshData {
        val positions = ArrayList<Float>()
        val normals = ArrayList<Float>()
        val uvs = ArrayList<Float>()
        val indices = ArrayList<Short>()

        // Shaft cylinder/box along +Y
        val shaftBase = (positions.size / 3).toShort()
        val r = 0.04f
        val h = 1.0f
        val sides = 8
        for (i in 0 until sides) {
            val a = i * 2f * Math.PI.toFloat() / sides
            val x = cos(a) * r
            val z = sin(a) * r
            positions.add(x); positions.add(0f); positions.add(z)
            normals.add(cos(a)); normals.add(0f); normals.add(sin(a))
            uvs.add(0f); uvs.add(0f)

            positions.add(x); positions.add(h); positions.add(z)
            normals.add(cos(a)); normals.add(0f); normals.add(sin(a))
            uvs.add(0f); uvs.add(1f)
        }
        for (i in 0 until sides) {
            val i0 = (shaftBase + i * 2).toShort()
            val i1 = (shaftBase + i * 2 + 1).toShort()
            val i2 = (shaftBase + ((i + 1) % sides) * 2 + 1).toShort()
            val i3 = (shaftBase + ((i + 1) % sides) * 2).toShort()
            indices.add(i0); indices.add(i1); indices.add(i2)
            indices.add(i0); indices.add(i2); indices.add(i3)
        }

        // Arrow head cone
        val coneTip = (positions.size / 3).toShort()
        positions.add(0f); positions.add(h + 0.35f); positions.add(0f)
        normals.add(0f); normals.add(1f); normals.add(0f)
        uvs.add(0.5f); uvs.add(1f)

        val coneBase = (positions.size / 3).toShort()
        val cr = 0.12f
        for (i in 0 until sides) {
            val a = i * 2f * Math.PI.toFloat() / sides
            val x = cos(a) * cr
            val z = sin(a) * cr
            positions.add(x); positions.add(h); positions.add(z)
            normals.add(cos(a)); normals.add(0.5f); normals.add(sin(a))
            uvs.add(0.5f); uvs.add(0f)
        }
        for (i in 0 until sides) {
            val c1 = (coneBase + i).toShort()
            val c2 = (coneBase + (i + 1) % sides).toShort()
            indices.add(coneTip); indices.add(c1); indices.add(c2)
        }

        return MeshData.createFromArrays(
            positions.toFloatArray(),
            normals.toFloatArray(),
            uvs.toFloatArray(),
            indices.toShortArray()
        )
    }

    // Basic Cube / Box primitive
    fun generateCube(size: Float = 1f): MeshData {
        val s = size / 2f
        val positions = floatArrayOf(
            -s, -s,  s,   s, -s,  s,   s,  s,  s,  -s,  s,  s,
             s, -s, -s,  -s, -s, -s,  -s,  s, -s,   s,  s, -s,
            -s,  s,  s,   s,  s,  s,   s,  s, -s,  -s,  s, -s,
            -s, -s, -s,   s, -s, -s,   s, -s,  s,  -s, -s,  s,
             s, -s,  s,   s, -s, -s,   s,  s, -s,   s,  s,  s,
            -s, -s, -s,  -s, -s,  s,  -s,  s,  s,  -s,  s, -s
        )
        val normals = floatArrayOf(
             0f,  0f,  1f,   0f,  0f,  1f,   0f,  0f,  1f,   0f,  0f,  1f,
             0f,  0f, -1f,   0f,  0f, -1f,   0f,  0f, -1f,   0f,  0f, -1f,
             0f,  1f,  0f,   0f,  1f,  0f,   0f,  1f,  0f,   0f,  1f,  0f,
             0f, -1f,  0f,   0f, -1f,  0f,   0f, -1f,  0f,   0f, -1f,  0f,
             1f,  0f,  0f,   1f,  0f,  0f,   1f,  0f,  0f,   1f,  0f,  0f,
            -1f,  0f,  0f,  -1f,  0f,  0f,  -1f,  0f,  0f,  -1f,  0f,  0f
        )
        val uvs = floatArrayOf(
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f,
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f,
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f,
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f,
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f,
            0f, 0f, 1f, 0f, 1f, 1f, 0f, 1f
        )
        val indices = shortArrayOf(
            0, 1, 2,  0, 2, 3,
            4, 5, 6,  4, 6, 7,
            8, 9, 10, 8, 10, 11,
            12, 13, 14, 12, 14, 15,
            16, 17, 18, 16, 18, 19,
            20, 21, 22, 20, 22, 23
        )
        return MeshData.createFromArrays(positions, normals, uvs, indices)
    }
}
