package com.example.dass.data

import com.example.dass.model.*
import org.json.JSONArray
import org.json.JSONObject

data class SceneBundle(
    val planetConfig: PlanetConfig,
    val objects: List<GameObject>,
    val settingsConfig: SettingsConfig
)

object SceneSerializer {

    fun serializeScene(bundle: SceneBundle): String {
        val root = JSONObject()

        // Planet Config
        val planet = JSONObject()
        planet.put("radius", bundle.planetConfig.radius.toDouble())
        planet.put("oceanRadius", bundle.planetConfig.oceanRadius.toDouble())
        planet.put("oceanColorHex", bundle.planetConfig.oceanColorHex)
        planet.put("terrainColorHex", bundle.planetConfig.terrainColorHex)
        planet.put("atmosphereColorHex", bundle.planetConfig.atmosphereColorHex)
        planet.put("waveSpeed", bundle.planetConfig.waveSpeed.toDouble())
        planet.put("waveAmplitude", bundle.planetConfig.waveAmplitude.toDouble())
        planet.put("atmosphereGlow", bundle.planetConfig.atmosphereGlow.toDouble())
        planet.put("seed", bundle.planetConfig.seed)
        planet.put("rotationSpeed", bundle.planetConfig.rotationSpeed.toDouble())
        root.put("planet", planet)

        // Game Objects
        val objectsArr = JSONArray()
        for (obj in bundle.objects) {
            val objJson = JSONObject()
            objJson.put("id", obj.id)
            objJson.put("name", obj.name)
            objJson.put("type", obj.type.name)
            objJson.put("meshKey", obj.meshKey)
            obj.customModelPath?.let { objJson.put("customModelPath", it) }

            // Position, Rotation, Scale
            val posJson = JSONObject()
            posJson.put("x", obj.position.x.toDouble())
            posJson.put("y", obj.position.y.toDouble())
            posJson.put("z", obj.position.z.toDouble())
            objJson.put("position", posJson)

            val rotJson = JSONObject()
            rotJson.put("x", obj.rotation.x.toDouble())
            rotJson.put("y", obj.rotation.y.toDouble())
            rotJson.put("z", obj.rotation.z.toDouble())
            objJson.put("rotation", rotJson)

            val scaleJson = JSONObject()
            scaleJson.put("x", obj.scale.x.toDouble())
            scaleJson.put("y", obj.scale.y.toDouble())
            scaleJson.put("z", obj.scale.z.toDouble())
            objJson.put("scale", scaleJson)

            // Material
            val matJson = JSONObject()
            matJson.put("albedoHex", obj.material.albedoHex)
            matJson.put("metallic", obj.material.metallic.toDouble())
            matJson.put("roughness", obj.material.roughness.toDouble())
            matJson.put("emissionHex", obj.material.emissionHex)
            matJson.put("emissionIntensity", obj.material.emissionIntensity.toDouble())
            matJson.put("textureKey", obj.material.textureKey)
            matJson.put("wireframe", obj.material.wireframe)
            objJson.put("material", matJson)

            // Animation
            val animJson = JSONObject()
            animJson.put("clipName", obj.animationState.clipName)
            animJson.put("speed", obj.animationState.speed.toDouble())
            animJson.put("isPlaying", obj.animationState.isPlaying)
            objJson.put("animation", animJson)

            // Vehicle
            obj.vehicleData?.let { v ->
                val vJson = JSONObject()
                vJson.put("type", v.type.name)
                vJson.put("maxSpeed", v.maxSpeed.toDouble())
                vJson.put("acceleration", v.acceleration.toDouble())
                vJson.put("steeringSensitivity", v.steeringSensitivity.toDouble())
                objJson.put("vehicle", vJson)
            }

            objectsArr.put(objJson)
        }
        root.put("objects", objectsArr)

        // Settings
        val set = JSONObject()
        set.put("targetFps", bundle.settingsConfig.targetFps.name)
        set.put("renderQuality", bundle.settingsConfig.renderQuality.name)
        set.put("gravity", bundle.settingsConfig.gravity.toDouble())
        set.put("sphericalGravity", bundle.settingsConfig.sphericalGravity)
        set.put("shadowEnabled", bundle.settingsConfig.shadowEnabled)
        set.put("bloomEnabled", bundle.settingsConfig.bloomEnabled)
        set.put("defaultPackagePrefix", bundle.settingsConfig.defaultPackagePrefix)
        root.put("settings", set)

        return root.toString(2)
    }

    fun deserializeScene(jsonStr: String): SceneBundle {
        val root = JSONObject(jsonStr)

        val planetObj = root.optJSONObject("planet")
        val planetConfig = if (planetObj != null) {
            PlanetConfig(
                radius = planetObj.optDouble("radius", 12.0).toFloat(),
                oceanRadius = planetObj.optDouble("oceanRadius", 12.2).toFloat(),
                oceanColorHex = planetObj.optString("oceanColorHex", "#0077B6"),
                terrainColorHex = planetObj.optString("terrainColorHex", "#2D6A4F"),
                atmosphereColorHex = planetObj.optString("atmosphereColorHex", "#00E5FF"),
                waveSpeed = planetObj.optDouble("waveSpeed", 1.2).toFloat(),
                waveAmplitude = planetObj.optDouble("waveAmplitude", 0.15).toFloat(),
                atmosphereGlow = planetObj.optDouble("atmosphereGlow", 1.5).toFloat(),
                seed = planetObj.optLong("seed", 42L),
                rotationSpeed = planetObj.optDouble("rotationSpeed", 0.05).toFloat()
            )
        } else {
            PlanetConfig()
        }

        val objects = mutableListOf<GameObject>()
        val objectsArr = root.optJSONArray("objects")
        if (objectsArr != null) {
            for (i in 0 until objectsArr.length()) {
                val objJson = objectsArr.getJSONObject(i)
                val id = objJson.optString("id", java.util.UUID.randomUUID().toString())
                val name = objJson.optString("name", "Object_$i")
                val typeStr = objJson.optString("type", ObjectType.PROP.name)
                val type = try { ObjectType.valueOf(typeStr) } catch (_: Exception) { ObjectType.PROP }
                val meshKey = objJson.optString("meshKey", "cube")
                val customPath = if (objJson.has("customModelPath")) objJson.getString("customModelPath") else null

                val posObj = objJson.optJSONObject("position")
                val pos = if (posObj != null) {
                    Vec3(
                        posObj.optDouble("x", 0.0).toFloat(),
                        posObj.optDouble("y", 0.0).toFloat(),
                        posObj.optDouble("z", 0.0).toFloat()
                    )
                } else Vec3()

                val rotObj = objJson.optJSONObject("rotation")
                val rot = if (rotObj != null) {
                    Vec3(
                        rotObj.optDouble("x", 0.0).toFloat(),
                        rotObj.optDouble("y", 0.0).toFloat(),
                        rotObj.optDouble("z", 0.0).toFloat()
                    )
                } else Vec3()

                val scaObj = objJson.optJSONObject("scale")
                val sca = if (scaObj != null) {
                    Vec3(
                        scaObj.optDouble("x", 1.0).toFloat(),
                        scaObj.optDouble("y", 1.0).toFloat(),
                        scaObj.optDouble("z", 1.0).toFloat()
                    )
                } else Vec3(1f, 1f, 1f)

                val matObj = objJson.optJSONObject("material")
                val mat = if (matObj != null) {
                    MaterialData(
                        albedoHex = matObj.optString("albedoHex", "#00E5FF"),
                        metallic = matObj.optDouble("metallic", 0.2).toFloat(),
                        roughness = matObj.optDouble("roughness", 0.4).toFloat(),
                        emissionHex = matObj.optString("emissionHex", "#000000"),
                        emissionIntensity = matObj.optDouble("emissionIntensity", 0.0).toFloat(),
                        textureKey = matObj.optString("textureKey", "grid"),
                        wireframe = matObj.optBoolean("wireframe", false)
                    )
                } else MaterialData()

                val animObj = objJson.optJSONObject("animation")
                val anim = if (animObj != null) {
                    AnimationState(
                        clipName = animObj.optString("clipName", "Idle"),
                        speed = animObj.optDouble("speed", 1.0).toFloat(),
                        isPlaying = animObj.optBoolean("isPlaying", true)
                    )
                } else AnimationState()

                val vehObj = objJson.optJSONObject("vehicle")
                val veh = if (vehObj != null) {
                    val vTypeStr = vehObj.optString("type", VehicleType.WHEELED.name)
                    val vType = try { VehicleType.valueOf(vTypeStr) } catch (_: Exception) { VehicleType.WHEELED }
                    VehicleData(
                        type = vType,
                        maxSpeed = vehObj.optDouble("maxSpeed", 18.0).toFloat(),
                        acceleration = vehObj.optDouble("acceleration", 8.0).toFloat(),
                        steeringSensitivity = vehObj.optDouble("steeringSensitivity", 1.5).toFloat()
                    )
                } else null

                objects.add(
                    GameObject(
                        id = id,
                        name = name,
                        type = type,
                        position = pos,
                        rotation = rot,
                        scale = sca,
                        material = mat,
                        animationState = anim,
                        vehicleData = veh,
                        meshKey = meshKey,
                        customModelPath = customPath
                    )
                )
            }
        }

        val setObj = root.optJSONObject("settings")
        val settings = if (setObj != null) {
            val fpsStr = setObj.optString("targetFps", TargetFps.FPS_60.name)
            val qualStr = setObj.optString("renderQuality", RenderQuality.MEDIUM.name)
            SettingsConfig(
                targetFps = try { TargetFps.valueOf(fpsStr) } catch (_: Exception) { TargetFps.FPS_60 },
                renderQuality = try { RenderQuality.valueOf(qualStr) } catch (_: Exception) { RenderQuality.MEDIUM },
                gravity = setObj.optDouble("gravity", -9.8).toFloat(),
                sphericalGravity = setObj.optBoolean("sphericalGravity", true),
                shadowEnabled = setObj.optBoolean("shadowEnabled", true),
                bloomEnabled = setObj.optBoolean("bloomEnabled", true),
                defaultPackagePrefix = setObj.optString("defaultPackagePrefix", "com.dass.game")
            )
        } else SettingsConfig()

        return SceneBundle(planetConfig, objects, settings)
    }
}
