package com.example.dass.engine.importer

import android.content.Context
import android.net.Uri
import com.example.dass.engine.graphics.MeshData
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader

object Model3DImporter {

    fun loadObj(inputStream: InputStream): MeshData {
        val reader = BufferedReader(InputStreamReader(inputStream))
        val rawPositions = ArrayList<Float>()
        val rawNormals = ArrayList<Float>()
        val rawUvs = ArrayList<Float>()

        val finalPositions = ArrayList<Float>()
        val finalNormals = ArrayList<Float>()
        val finalUvs = ArrayList<Float>()
        val finalIndices = ArrayList<Short>()

        var line: String?
        while (reader.readLine().also { line = it } != null) {
            val trimmed = line?.trim() ?: continue
            if (trimmed.startsWith("#") || trimmed.isEmpty()) continue

            val parts = trimmed.split("\\s+".toRegex())
            when (parts[0]) {
                "v" -> {
                    if (parts.size >= 4) {
                        rawPositions.add(parts[1].toFloat())
                        rawPositions.add(parts[2].toFloat())
                        rawPositions.add(parts[3].toFloat())
                    }
                }
                "vn" -> {
                    if (parts.size >= 4) {
                        rawNormals.add(parts[1].toFloat())
                        rawNormals.add(parts[2].toFloat())
                        rawNormals.add(parts[3].toFloat())
                    }
                }
                "vt" -> {
                    if (parts.size >= 3) {
                        rawUvs.add(parts[1].toFloat())
                        rawUvs.add(parts[2].toFloat())
                    }
                }
                "f" -> {
                    // Face definition e.g. f 1/1/1 2/2/2 3/3/3
                    val faceIndices = mutableListOf<Short>()
                    for (i in 1 until parts.size) {
                        val vertexTokens = parts[i].split("/")
                        val vIdx = (vertexTokens[0].toInt() - 1) * 3
                        val vtIdx = if (vertexTokens.size > 1 && vertexTokens[1].isNotEmpty()) (vertexTokens[1].toInt() - 1) * 2 else -1
                        val vnIdx = if (vertexTokens.size > 2 && vertexTokens[2].isNotEmpty()) (vertexTokens[2].toInt() - 1) * 3 else -1

                        val curShort = (finalPositions.size / 3).toShort()

                        if (vIdx >= 0 && vIdx + 2 < rawPositions.size) {
                            finalPositions.add(rawPositions[vIdx])
                            finalPositions.add(rawPositions[vIdx + 1])
                            finalPositions.add(rawPositions[vIdx + 2])
                        } else {
                            finalPositions.add(0f); finalPositions.add(0f); finalPositions.add(0f)
                        }

                        if (vnIdx >= 0 && vnIdx + 2 < rawNormals.size) {
                            finalNormals.add(rawNormals[vnIdx])
                            finalNormals.add(rawNormals[vnIdx + 1])
                            finalNormals.add(rawNormals[vnIdx + 2])
                        } else {
                            finalNormals.add(0f); finalNormals.add(1f); finalNormals.add(0f)
                        }

                        if (vtIdx >= 0 && vtIdx + 1 < rawUvs.size) {
                            finalUvs.add(rawUvs[vtIdx])
                            finalUvs.add(rawUvs[vtIdx + 1])
                        } else {
                            finalUvs.add(0.5f); finalUvs.add(0.5f)
                        }

                        faceIndices.add(curShort)
                    }

                    // Triangulate face if fan (quad or polygon)
                    for (i in 1 until faceIndices.size - 1) {
                        finalIndices.add(faceIndices[0])
                        finalIndices.add(faceIndices[i])
                        finalIndices.add(faceIndices[i + 1])
                    }
                }
            }
        }
        reader.close()

        return MeshData.createFromArrays(
            finalPositions.toFloatArray(),
            finalNormals.toFloatArray(),
            finalUvs.toFloatArray(),
            finalIndices.toShortArray()
        )
    }

    fun loadFromUri(context: Context, uri: Uri): Result<MeshData> {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return Result.failure(Exception("Cannot open stream for URI $uri"))
            val mesh = loadObj(inputStream)
            Result.success(mesh)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
