package com.example.dass.engine.graphics

import android.graphics.Color
import android.opengl.GLES20
import android.util.Log

class ShaderProgram(val programId: Int) {
    val uMVPMatrix: Int = GLES20.glGetUniformLocation(programId, "uMVPMatrix")
    val uModelMatrix: Int = GLES20.glGetUniformLocation(programId, "uModelMatrix")
    val uViewPos: Int = GLES20.glGetUniformLocation(programId, "uViewPos")
    val uLightDir: Int = GLES20.glGetUniformLocation(programId, "uLightDir")
    val uBaseColor: Int = GLES20.glGetUniformLocation(programId, "uBaseColor")
    val uMetallic: Int = GLES20.glGetUniformLocation(programId, "uMetallic")
    val uRoughness: Int = GLES20.glGetUniformLocation(programId, "uRoughness")
    val uEmission: Int = GLES20.glGetUniformLocation(programId, "uEmission")
    val uIsWater: Int = GLES20.glGetUniformLocation(programId, "uIsWater")
    val uTime: Int = GLES20.glGetUniformLocation(programId, "uTime")
    val uWaveSpeed: Int = GLES20.glGetUniformLocation(programId, "uWaveSpeed")
    val uWaveAmplitude: Int = GLES20.glGetUniformLocation(programId, "uWaveAmplitude")
    val uIsAtmosphere: Int = GLES20.glGetUniformLocation(programId, "uIsAtmosphere")
    val uSelected: Int = GLES20.glGetUniformLocation(programId, "uSelected")

    val aPosition: Int = GLES20.glGetAttribLocation(programId, "aPosition")
    val aNormal: Int = GLES20.glGetAttribLocation(programId, "aNormal")
    val aUV: Int = GLES20.glGetAttribLocation(programId, "aUV")

    fun use() {
        GLES20.glUseProgram(programId)
    }

    companion object {
        private const val VERTEX_SHADER_CODE = """
            uniform mat4 uMVPMatrix;
            uniform mat4 uModelMatrix;
            uniform float uTime;
            uniform float uIsWater;
            uniform float uWaveSpeed;
            uniform float uWaveAmplitude;

            attribute vec4 aPosition;
            attribute vec3 aNormal;
            attribute vec2 aUV;

            varying vec3 vWorldPos;
            varying vec3 vNormal;
            varying vec2 vUV;

            void main() {
                vec4 pos = aPosition;

                // Spherical water wave displacement
                if (uIsWater > 0.5) {
                    float wave = sin(pos.x * 3.0 + uTime * uWaveSpeed) * 
                                 cos(pos.z * 3.0 + uTime * uWaveSpeed * 0.8) * uWaveAmplitude;
                    pos.xyz += aNormal * wave;
                }

                vec4 worldPos = uModelMatrix * pos;
                vWorldPos = worldPos.xyz;
                vNormal = normalize(mat3(uModelMatrix) * aNormal);
                vUV = aUV;
                gl_Position = uMVPMatrix * pos;
            }
        """

        private const val FRAGMENT_SHADER_CODE = """
            precision mediump float;

            uniform vec3 uViewPos;
            uniform vec3 uLightDir;
            uniform vec4 uBaseColor;
            uniform float uMetallic;
            uniform float uRoughness;
            uniform vec4 uEmission;
            uniform float uIsWater;
            uniform float uIsAtmosphere;
            uniform float uSelected;
            uniform float uTime;

            varying vec3 vWorldPos;
            varying vec3 vNormal;
            varying vec2 vUV;

            void main() {
                vec3 N = normalize(vNormal);
                vec3 L = normalize(uLightDir);
                vec3 V = normalize(uViewPos - vWorldPos);

                // Atmosphere halo / scattering mode
                if (uIsAtmosphere > 0.5) {
                    float fresnel = 1.0 - max(dot(N, V), 0.0);
                    fresnel = pow(fresnel, 2.5);
                    gl_FragColor = vec4(uBaseColor.rgb * 1.5, fresnel * uBaseColor.a);
                    return;
                }

                // Ambient light
                vec3 ambient = vec3(0.12, 0.15, 0.22) * uBaseColor.rgb;

                // Diffuse lighting
                float diff = max(dot(N, L), 0.0);
                vec3 diffuse = diff * uBaseColor.rgb;

                // Specular reflection (Blinn-Phong / PBR approximation)
                vec3 H = normalize(L + V);
                float shininess = (1.0 - clamp(uRoughness, 0.05, 0.95)) * 128.0;
                float spec = pow(max(dot(N, H), 0.0), shininess);
                vec3 specColor = mix(vec3(0.04), uBaseColor.rgb, uMetallic);
                vec3 specular = spec * specColor * (diff > 0.0 ? 1.0 : 0.0);

                // Water shader with dynamic sparkles & fresnel transparency
                if (uIsWater > 0.5) {
                    float fresnel = pow(1.0 - max(dot(N, V), 0.0), 3.0);
                    vec3 waterColor = mix(uBaseColor.rgb, vec3(0.3, 0.85, 1.0), fresnel * 0.7);
                    float sparkle = pow(max(dot(N, H), 0.0), 64.0) * 1.5;
                    gl_FragColor = vec4(waterColor + sparkle * vec3(1.0), 0.88);
                    return;
                }

                // Object selection highlight outline / pulse
                vec3 finalColor = ambient + diffuse + specular + uEmission.rgb * uEmission.a;
                if (uSelected > 0.5) {
                    float pulse = 0.7 + 0.3 * sin(uTime * 6.0);
                    finalColor += vec3(0.0, 0.9, 1.0) * pulse * 0.45;
                }

                gl_FragColor = vec4(finalColor, uBaseColor.a);
            }
        """

        fun create(): ShaderProgram {
            val vShader = compileShader(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER_CODE)
            val fShader = compileShader(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER_CODE)
            val prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vShader)
            GLES20.glAttachShader(prog, fShader)
            GLES20.glLinkProgram(prog)

            val status = IntArray(1)
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(prog)
                Log.e("DassShader", "Program link failed: $log")
                GLES20.glDeleteProgram(prog)
                throw RuntimeException("Shader link failed: $log")
            }

            return ShaderProgram(prog)
        }

        private fun compileShader(type: Int, code: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, code)
            GLES20.glCompileShader(shader)
            val status = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(shader)
                Log.e("DassShader", "Shader compile failed ($type): $log")
                GLES20.glDeleteShader(shader)
                throw RuntimeException("Shader compile error: $log")
            }
            return shader
        }

        fun parseColor(hex: String, defaultColor: FloatArray = floatArrayOf(0f, 0.9f, 1f, 1f)): FloatArray {
            return try {
                val parsed = Color.parseColor(hex)
                floatArrayOf(
                    Color.red(parsed) / 255f,
                    Color.green(parsed) / 255f,
                    Color.blue(parsed) / 255f,
                    Color.alpha(parsed) / 255f
                )
            } catch (_: Exception) {
                defaultColor
            }
        }
    }
}
