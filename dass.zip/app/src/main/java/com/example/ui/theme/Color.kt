package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dass High-Tech 3D Game Engine Dark Palette
val VoidBlack = Color(0xFF070A10)
val DarkNavy = Color(0xFF0C121E)
val SurfaceDark = Color(0xFF131C2E)
val SurfaceElevated = Color(0xFF1A263D)
val SurfaceCard = Color(0xFF182338)
val SurfaceBorder = Color(0xFF263753)

val CyanNeon = Color(0xFF00E5FF)
val CyanAccent = Color(0xFF80F0FF)
val PurpleQuantum = Color(0xFF7C4DFF)
val PurpleNeon = Color(0xFFB388FF)
val AmberEnergy = Color(0xFFFF9100)
val EmeraldSuccess = Color(0xFF00E676)
val CrimsonAlert = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val OceanBlue = Color(0xFF0077B6)
val DeepOcean = Color(0xFF03045E)
val AtmosphereCyan = Color(0xFF48CAE4)
