package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DassDarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = VoidBlack,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = CyanAccent,
    secondary = PurpleQuantum,
    onSecondary = VoidBlack,
    secondaryContainer = SurfaceCard,
    onSecondaryContainer = PurpleNeon,
    tertiary = AmberEnergy,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = TextPrimary,
    surface = DarkNavy,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = SurfaceBorder,
    error = CrimsonAlert,
    onError = VoidBlack
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force modern dark mode for game engine UI
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = VoidBlack.toArgb()
                it.navigationBarColor = VoidBlack.toArgb()
                WindowCompat.getInsetsController(it, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = DassDarkColorScheme,
        typography = Typography,
        content = content
    )
}
