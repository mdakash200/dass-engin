package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.dass.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.VoidBlack

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: DassViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                var showExportDialog by remember { mutableStateOf(false) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(VoidBlack)
                ) {
                    when (currentScreen) {
                        DassScreen.HOME -> {
                            HomeScreen(viewModel = viewModel)
                        }
                        DassScreen.ENGINE_CANVAS -> {
                            EngineCanvasScreen(
                                viewModel = viewModel,
                                onOpenExport = { showExportDialog = true }
                            )
                        }
                        DassScreen.SETTINGS -> {
                            SettingsScreen(viewModel = viewModel)
                        }
                    }

                    if (showExportDialog) {
                        ExportApkDialog(
                            viewModel = viewModel,
                            onDismiss = { showExportDialog = false }
                        )
                    }
                }
            }
        }
    }
}
